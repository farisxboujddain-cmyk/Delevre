import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'core/router/app_router.dart';
import 'core/theme/app_theme.dart';
import 'core/providers/app_providers.dart';
import 'core/services/notification_service.dart';
import 'core/services/payment_service.dart';
import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // ── System UI ──────────────────────────────
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: FesColors.cardDark,
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // ── Firebase ───────────────────────────────
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  // ── Stripe ─────────────────────────────────
  PaymentService.initialize(
    const String.fromEnvironment('STRIPE_PUBLISHABLE_KEY',
      defaultValue: 'pk_test_XXXXXXXXXXXXXXXXXXXXXXXX'),
  );

  runApp(const ProviderScope(child: FesDeliverApp()));
}

class FesDeliverApp extends ConsumerWidget {
  const FesDeliverApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final router = ref.watch(routerProvider);
    final isDark = ref.watch(themeModeProvider);

    // Initialize notifications after first build
    ref.listen(authStateProvider, (_, next) {
      next.whenData((user) {
        if (user != null) {
          ref.read(notificationServiceProvider).initialize();
        }
      });
    });

    return MaterialApp.router(
      title: 'FesDeliver',
      debugShowCheckedModeBanner: false,
      theme: FesTheme.light(),
      darkTheme: FesTheme.dark(),
      themeMode: isDark ? ThemeMode.dark : ThemeMode.light,
      routerConfig: router,

      // RTL Arabic support
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child!,
      ),

      localizationsDelegates: const [
        // Add flutter_localizations delegates here
      ],
      supportedLocales: const [
        Locale('ar', 'MA'),
        Locale('fr', 'MA'),
        Locale('en', 'US'),
      ],
    );
  }
}
