import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// ─────────────────────────────────────────────
//  FesDeliver Design Tokens
//  Moroccan Green + Gold palette
// ─────────────────────────────────────────────
class FesColors {
  FesColors._();

  // Brand
  static const green        = Color(0xFF1B6B3A);
  static const greenLight   = Color(0xFF2A8A4E);
  static const greenDark    = Color(0xFF134D2A);
  static const gold         = Color(0xFFC9A84C);
  static const goldLight    = Color(0xFFE2C06A);
  static const goldDark     = Color(0xFF9E7B30);

  // Dark surfaces
  static const bgDark       = Color(0xFF0D1F14);
  static const cardDark     = Color(0xFF132A1C);
  static const cardLightDark= Color(0xFF1A3524);
  static const surfaceDark  = Color(0xFF0F2318);

  // Light surfaces
  static const bgLight      = Color(0xFFF0F5F1);
  static const cardLight    = Color(0xFFFFFFFF);
  static const surfaceLight = Color(0xFFE2EDE5);

  // Status
  static const success      = Color(0xFF4CAF82);
  static const danger       = Color(0xFFE05252);
  static const warning      = Color(0xFFE8A838);
  static const info         = Color(0xFF4A9EBF);

  // Text dark
  static const textDark         = Color(0xFFF5EDD8);
  static const textMutedDark    = Color(0xFF8BA899);

  // Text light
  static const textLight        = Color(0xFF0D1F14);
  static const textMutedLight   = Color(0xFF5A7A65);
}

class FesTheme {
  FesTheme._();

  static ThemeData dark() => ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    fontFamily: 'Cairo',
    colorScheme: const ColorScheme.dark(
      primary:   FesColors.green,
      secondary: FesColors.gold,
      surface:   FesColors.cardDark,
      background: FesColors.bgDark,
      error:     FesColors.danger,
      onPrimary: Colors.white,
      onSecondary: FesColors.bgDark,
      onSurface: FesColors.textDark,
      onBackground: FesColors.textDark,
    ),
    scaffoldBackgroundColor: FesColors.bgDark,
    cardColor: FesColors.cardDark,
    appBarTheme: const AppBarTheme(
      backgroundColor: FesColors.cardDark,
      foregroundColor: FesColors.textDark,
      elevation: 0,
      centerTitle: true,
      systemOverlayStyle: SystemUiOverlayStyle(
        statusBarBrightness: Brightness.dark,
        statusBarIconBrightness: Brightness.light,
      ),
    ),
    textTheme: _buildTextTheme(FesColors.textDark, FesColors.textMutedDark),
    inputDecorationTheme: _inputTheme(dark: true),
    elevatedButtonTheme: _buttonTheme(),
    cardTheme: _cardTheme(FesColors.cardDark),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: FesColors.cardDark,
      selectedItemColor: FesColors.green,
      unselectedItemColor: FesColors.textMutedDark,
      showSelectedLabels: true,
      showUnselectedLabels: true,
      type: BottomNavigationBarType.fixed,
      elevation: 0,
    ),
  );

  static ThemeData light() => ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    fontFamily: 'Cairo',
    colorScheme: const ColorScheme.light(
      primary:   FesColors.green,
      secondary: FesColors.gold,
      surface:   FesColors.cardLight,
      background: FesColors.bgLight,
      error:     FesColors.danger,
      onPrimary: Colors.white,
      onSecondary: FesColors.bgDark,
      onSurface: FesColors.textLight,
      onBackground: FesColors.textLight,
    ),
    scaffoldBackgroundColor: FesColors.bgLight,
    cardColor: FesColors.cardLight,
    appBarTheme: const AppBarTheme(
      backgroundColor: FesColors.cardLight,
      foregroundColor: FesColors.textLight,
      elevation: 0,
      centerTitle: true,
    ),
    textTheme: _buildTextTheme(FesColors.textLight, FesColors.textMutedLight),
    inputDecorationTheme: _inputTheme(dark: false),
    elevatedButtonTheme: _buttonTheme(),
    cardTheme: _cardTheme(FesColors.cardLight),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: FesColors.cardLight,
      selectedItemColor: FesColors.green,
      unselectedItemColor: FesColors.textMutedLight,
      showSelectedLabels: true,
      showUnselectedLabels: true,
      type: BottomNavigationBarType.fixed,
    ),
  );

  static TextTheme _buildTextTheme(Color primary, Color muted) => TextTheme(
    displayLarge:  TextStyle(fontSize: 36, fontWeight: FontWeight.w900, color: primary, fontFamily: 'Cairo'),
    displayMedium: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: primary, fontFamily: 'Cairo'),
    headlineLarge: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: primary, fontFamily: 'Cairo'),
    headlineMedium:TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: primary, fontFamily: 'Cairo'),
    headlineSmall: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: primary, fontFamily: 'Cairo'),
    bodyLarge:     TextStyle(fontSize: 15, fontWeight: FontWeight.w400, color: primary, fontFamily: 'Cairo'),
    bodyMedium:    TextStyle(fontSize: 14, fontWeight: FontWeight.w400, color: primary, fontFamily: 'Cairo'),
    bodySmall:     TextStyle(fontSize: 12, fontWeight: FontWeight.w400, color: muted,   fontFamily: 'Cairo'),
    labelLarge:    TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: primary, fontFamily: 'Cairo'),
    labelSmall:    TextStyle(fontSize: 11, fontWeight: FontWeight.w500, color: muted,   fontFamily: 'Cairo'),
  );

  static InputDecorationTheme _inputTheme({required bool dark}) => InputDecorationTheme(
    filled: true,
    fillColor: dark ? FesColors.cardDark : FesColors.cardLight,
    contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: BorderSide(color: dark ? FesColors.cardLightDark : FesColors.surfaceLight),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: BorderSide(color: dark ? FesColors.cardLightDark : FesColors.surfaceLight),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: const BorderSide(color: FesColors.green, width: 2),
    ),
    hintStyle: TextStyle(color: dark ? FesColors.textMutedDark : FesColors.textMutedLight, fontSize: 14),
  );

  static ElevatedButtonThemeData _buttonTheme() => ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: FesColors.green,
      foregroundColor: Colors.white,
      minimumSize: const Size(double.infinity, 54),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 0,
      textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, fontFamily: 'Cairo'),
    ),
  );

  static CardTheme _cardTheme(Color color) => CardTheme(
    color: color,
    elevation: 0,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
    margin: EdgeInsets.zero,
  );
}
