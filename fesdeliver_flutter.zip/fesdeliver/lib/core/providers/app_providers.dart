import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/firebase_services.dart';
import '../models/models.dart';
import '../constants/app_constants.dart';

// ─────────────────────────────────────────────
//  Auth State
// ─────────────────────────────────────────────
final authStateProvider = StreamProvider<User?>((ref) {
  return ref.watch(firebaseAuthProvider).authStateChanges();
});

final currentUserProvider = FutureProvider<UserModel?>((ref) async {
  final authUser = await ref.watch(authStateProvider.future);
  if (authUser == null) return null;
  return ref.watch(authServiceProvider).getUser(authUser.uid);
});

// ─────────────────────────────────────────────
//  Theme Mode
// ─────────────────────────────────────────────
final themeModeProvider = StateNotifierProvider<ThemeModeNotifier, bool>((ref) {
  return ThemeModeNotifier();
});

class ThemeModeNotifier extends StateNotifier<bool> {
  ThemeModeNotifier() : super(true) { // true = dark
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    state = prefs.getBool(AppConstants.prefThemeMode) ?? true;
  }

  Future<void> toggle() async {
    state = !state;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(AppConstants.prefThemeMode, state);
  }
}

// ─────────────────────────────────────────────
//  Cart State
// ─────────────────────────────────────────────
class CartNotifier extends StateNotifier<List<CartItem>> {
  CartNotifier() : super([]);

  String? _restaurantId;
  String? get restaurantId => _restaurantId;

  void addItem(MenuItemModel item, {String? restaurantId}) {
    // Clear cart if switching restaurant
    if (restaurantId != null && restaurantId != _restaurantId) {
      state = [];
      _restaurantId = restaurantId;
    }

    final idx = state.indexWhere((c) => c.menuItem.id == item.id);
    if (idx >= 0) {
      state = [
        ...state.sublist(0, idx),
        state[idx].copyWith(quantity: state[idx].quantity + 1),
        ...state.sublist(idx + 1),
      ];
    } else {
      state = [...state, CartItem(menuItem: item, quantity: 1)];
    }
  }

  void removeItem(String itemId) {
    final idx = state.indexWhere((c) => c.menuItem.id == itemId);
    if (idx < 0) return;
    if (state[idx].quantity <= 1) {
      state = state.where((c) => c.menuItem.id != itemId).toList();
    } else {
      state = [
        ...state.sublist(0, idx),
        state[idx].copyWith(quantity: state[idx].quantity - 1),
        ...state.sublist(idx + 1),
      ];
    }
  }

  void clearCart() {
    state = [];
    _restaurantId = null;
  }

  double get subtotal =>
      state.fold(0, (sum, item) => sum + item.menuItem.price * item.quantity);

  int get totalItems =>
      state.fold(0, (sum, item) => sum + item.quantity);
}

final cartProvider = StateNotifierProvider<CartNotifier, List<CartItem>>(
  (_) => CartNotifier(),
);

final cartTotalProvider = Provider<double>((ref) {
  final cart = ref.watch(cartProvider.notifier);
  return cart.subtotal;
});

final cartCountProvider = Provider<int>((ref) {
  return ref.watch(cartProvider).fold(0, (sum, item) => sum + item.quantity);
});

// ─────────────────────────────────────────────
//  Wallet State
// ─────────────────────────────────────────────
final walletProvider = StreamProvider<WalletModel?>((ref) {
  final user = ref.watch(authStateProvider).value;
  if (user == null) return Stream.value(null);
  return ref.watch(walletServiceProvider).watchWallet(user.uid);
});

final transactionsProvider = StreamProvider<List<TransactionModel>>((ref) {
  final user = ref.watch(authStateProvider).value;
  if (user == null) return Stream.value([]);
  return ref.watch(walletServiceProvider).watchTransactions(user.uid);
});

// ─────────────────────────────────────────────
//  Current Order (active tracking)
// ─────────────────────────────────────────────
final activeOrderIdProvider = StateProvider<String?>((ref) => null);

final activeOrderProvider = StreamProvider<OrderModel?>((ref) {
  final orderId = ref.watch(activeOrderIdProvider);
  if (orderId == null) return Stream.value(null);
  return ref.watch(orderServiceProvider).watchOrder(orderId);
});

// ─────────────────────────────────────────────
//  Driver online status (driver role)
// ─────────────────────────────────────────────
final driverOnlineProvider = StateNotifierProvider<DriverOnlineNotifier, bool>(
  (_) => DriverOnlineNotifier(),
);

class DriverOnlineNotifier extends StateNotifier<bool> {
  DriverOnlineNotifier() : super(false);

  void toggle() => state = !state;
  void setOnline(bool online) => state = online;
}

// ─────────────────────────────────────────────
//  Promo code
// ─────────────────────────────────────────────
final appliedPromoProvider = StateProvider<PromoCodeModel?>((ref) => null);
