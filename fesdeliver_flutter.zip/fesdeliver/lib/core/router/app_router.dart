import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../features/auth/presentation/screens/splash_screen.dart';
import '../../features/auth/presentation/screens/login_screen.dart';
import '../../features/auth/presentation/screens/otp_screen.dart';
import '../../features/auth/presentation/screens/role_select_screen.dart';
import '../../features/home/presentation/screens/home_screen.dart';
import '../../features/restaurant/presentation/screens/restaurant_screen.dart';
import '../../features/cart/presentation/screens/cart_screen.dart';
import '../../features/orders/presentation/screens/orders_screen.dart';
import '../../features/tracking/presentation/screens/tracking_screen.dart';
import '../../features/wallet/presentation/screens/wallet_screen.dart';
import '../../features/chatbot/presentation/screens/chatbot_screen.dart';
import '../../features/admin/presentation/screens/admin_dashboard_screen.dart';
import '../shell/main_shell.dart';
import '../providers/auth_state_provider.dart';

// Route names
class AppRoutes {
  static const splash      = '/';
  static const login       = '/login';
  static const otp         = '/otp';
  static const roleSelect  = '/role-select';
  static const home        = '/home';
  static const restaurant  = '/restaurant/:id';
  static const cart        = '/cart';
  static const orders      = '/orders';
  static const tracking    = '/tracking/:orderId';
  static const wallet      = '/wallet';
  static const chatbot     = '/chatbot';
  static const admin       = '/admin';
}

final routerProvider = Provider<GoRouter>((ref) {
  final authState = ref.watch(authStateProvider);

  return GoRouter(
    initialLocation: AppRoutes.splash,
    redirect: (context, state) {
      final isLoggedIn    = authState.value != null;
      final isAuthRoute   = state.matchedLocation.startsWith('/login') ||
                            state.matchedLocation == '/' ||
                            state.matchedLocation.startsWith('/otp') ||
                            state.matchedLocation.startsWith('/role');

      if (!isLoggedIn && !isAuthRoute) return AppRoutes.login;
      if (isLoggedIn && isAuthRoute && state.matchedLocation != '/') {
        return AppRoutes.home;
      }
      return null;
    },
    routes: [
      // Splash
      GoRoute(path: AppRoutes.splash, builder: (_, __) => const SplashScreen()),

      // Auth routes
      GoRoute(path: AppRoutes.login,      builder: (_, __) => const LoginScreen()),
      GoRoute(path: AppRoutes.otp,        builder: (_, state) => OtpScreen(phone: state.extra as String)),
      GoRoute(path: AppRoutes.roleSelect, builder: (_, __) => const RoleSelectScreen()),

      // Admin
      GoRoute(path: AppRoutes.admin, builder: (_, __) => const AdminDashboardScreen()),

      // Main shell with bottom nav
      ShellRoute(
        builder: (context, state, child) => MainShell(child: child),
        routes: [
          GoRoute(
            path: AppRoutes.home,
            builder: (_, __) => const HomeScreen(),
          ),
          GoRoute(
            path: AppRoutes.orders,
            builder: (_, __) => const OrdersScreen(),
          ),
          GoRoute(
            path: AppRoutes.wallet,
            builder: (_, __) => const WalletScreen(),
          ),
          GoRoute(
            path: AppRoutes.chatbot,
            builder: (_, __) => const ChatbotScreen(),
          ),
        ],
      ),

      // Full screen routes (no bottom nav)
      GoRoute(
        path: AppRoutes.restaurant,
        builder: (_, state) => RestaurantScreen(restaurantId: state.pathParameters['id']!),
      ),
      GoRoute(
        path: AppRoutes.cart,
        builder: (_, __) => const CartScreen(),
      ),
      GoRoute(
        path: AppRoutes.tracking,
        builder: (_, state) => TrackingScreen(orderId: state.pathParameters['orderId']!),
      ),
    ],

    errorBuilder: (context, state) => Scaffold(
      body: Center(
        child: Text('404 — الصفحة غير موجودة\n${state.error}'),
      ),
    ),
  );
});
