import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'models.freezed.dart';
part 'models.g.dart';

// ─────────────────────────────────────────────
//  USER MODEL
// ─────────────────────────────────────────────
@freezed
class UserModel with _$UserModel {
  const factory UserModel({
    required String id,
    required String name,
    required String phone,
    String? email,
    String? photoUrl,
    required String role,            // customer | merchant | driver | admin
    @Default(false) bool isVerified,
    @Default(false) bool isActive,
    String? fcmToken,
    GeoPoint? location,
    @Default('ar') String language,
    @Default('dark') String themeMode,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) = _UserModel;

  factory UserModel.fromJson(Map<String, dynamic> json) =>
      _$UserModelFromJson(json);

  factory UserModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return UserModel.fromJson({...data, 'id': doc.id});
  }
}

// ─────────────────────────────────────────────
//  RESTAURANT MODEL
// ─────────────────────────────────────────────
@freezed
class RestaurantModel with _$RestaurantModel {
  const factory RestaurantModel({
    required String id,
    required String ownerId,
    required String nameAr,
    required String nameFr,
    required String cuisine,
    String? descriptionAr,
    String? descriptionFr,
    required String coverUrl,
    String? logoUrl,
    required GeoPoint location,
    required String address,
    required double rating,
    @Default(0) int reviewsCount,
    @Default(10.0) double deliveryFee,
    required String minDeliveryTime,  // "20-30"
    @Default(0.0) double minOrderAmount,
    @Default(true) bool isOpen,
    @Default([]) List<String> categories,
    @Default([]) List<String> openingHours,
    @Default('pending') String status, // pending | approved | suspended
    DateTime? createdAt,
  }) = _RestaurantModel;

  factory RestaurantModel.fromJson(Map<String, dynamic> json) =>
      _$RestaurantModelFromJson(json);

  factory RestaurantModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return RestaurantModel.fromJson({...data, 'id': doc.id});
  }
}

// ─────────────────────────────────────────────
//  MENU ITEM MODEL
// ─────────────────────────────────────────────
@freezed
class MenuItemModel with _$MenuItemModel {
  const factory MenuItemModel({
    required String id,
    required String restaurantId,
    required String nameAr,
    String? nameFr,
    String? descriptionAr,
    String? descriptionFr,
    required double price,
    required String imageUrl,
    required String category,
    @Default(true) bool isAvailable,
    @Default(false) bool isPopular,
    @Default(false) bool isSpicy,
    @Default(false) bool isVegetarian,
    @Default([]) List<MenuItemOption> options,
    int? prepTimeMinutes,
    DateTime? createdAt,
  }) = _MenuItemModel;

  factory MenuItemModel.fromJson(Map<String, dynamic> json) =>
      _$MenuItemModelFromJson(json);
}

@freezed
class MenuItemOption with _$MenuItemOption {
  const factory MenuItemOption({
    required String nameAr,
    required double price,
    @Default(false) bool isDefault,
  }) = _MenuItemOption;

  factory MenuItemOption.fromJson(Map<String, dynamic> json) =>
      _$MenuItemOptionFromJson(json);
}

// ─────────────────────────────────────────────
//  CART ITEM
// ─────────────────────────────────────────────
@freezed
class CartItem with _$CartItem {
  const factory CartItem({
    required MenuItemModel menuItem,
    required int quantity,
    String? note,
    @Default([]) List<MenuItemOption> selectedOptions,
  }) = _CartItem;

  factory CartItem.fromJson(Map<String, dynamic> json) =>
      _$CartItemFromJson(json);
}

// ─────────────────────────────────────────────
//  ORDER MODEL
// ─────────────────────────────────────────────
@freezed
class OrderModel with _$OrderModel {
  const factory OrderModel({
    required String id,
    required String customerId,
    required String restaurantId,
    String? driverId,
    required List<OrderItem> items,
    required double subtotal,
    required double deliveryFee,
    @Default(0.0) double discount,
    required double total,
    required String status,
    required String paymentMethod,
    @Default(false) bool isPaid,
    required GeoPoint deliveryLocation,
    required String deliveryAddress,
    String? promoCode,
    String? note,
    String? cancellationReason,
    String? aiDriverMatch,          // AI explanation
    int? estimatedMinutes,          // AI ETA
    GeoPoint? driverLocation,       // real-time
    DateTime? acceptedAt,
    DateTime? preparedAt,
    DateTime? pickedAt,
    DateTime? deliveredAt,
    required DateTime createdAt,
    DateTime? updatedAt,
  }) = _OrderModel;

  factory OrderModel.fromJson(Map<String, dynamic> json) =>
      _$OrderModelFromJson(json);

  factory OrderModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return OrderModel.fromJson({...data, 'id': doc.id});
  }
}

@freezed
class OrderItem with _$OrderItem {
  const factory OrderItem({
    required String menuItemId,
    required String nameAr,
    required int quantity,
    required double price,
    String? note,
  }) = _OrderItem;

  factory OrderItem.fromJson(Map<String, dynamic> json) =>
      _$OrderItemFromJson(json);
}

// ─────────────────────────────────────────────
//  WALLET MODEL
// ─────────────────────────────────────────────
@freezed
class WalletModel with _$WalletModel {
  const factory WalletModel({
    required String userId,
    @Default(0.0) double balance,
    @Default(0) int loyaltyPoints,
    @Default(true) bool isActive,
    DateTime? updatedAt,
  }) = _WalletModel;

  factory WalletModel.fromJson(Map<String, dynamic> json) =>
      _$WalletModelFromJson(json);
}

@freezed
class TransactionModel with _$TransactionModel {
  const factory TransactionModel({
    required String id,
    required String userId,
    required String type,    // credit | debit | transfer_in | transfer_out | refund
    required double amount,
    required String description,
    String? referenceId,     // order id or transfer id
    String? fromUserId,
    String? toUserId,
    required String status,  // pending | completed | failed
    required DateTime createdAt,
  }) = _TransactionModel;

  factory TransactionModel.fromJson(Map<String, dynamic> json) =>
      _$TransactionModelFromJson(json);
}

// ─────────────────────────────────────────────
//  DRIVER MODEL
// ─────────────────────────────────────────────
@freezed
class DriverModel with _$DriverModel {
  const factory DriverModel({
    required String userId,
    required String vehicleType,   // motorcycle | car | bicycle
    required String vehiclePlate,
    required String cinNumber,
    required String cinImageUrl,
    String? profileImageUrl,
    @Default(true) bool isOnline,
    @Default(true) bool isAvailable,
    GeoPoint? currentLocation,
    double? heading,
    @Default(0.0) double totalEarnings,
    @Default(0) int totalDeliveries,
    @Default(5.0) double rating,
    @Default('pending') String verificationStatus,
    DateTime? lastSeen,
  }) = _DriverModel;

  factory DriverModel.fromJson(Map<String, dynamic> json) =>
      _$DriverModelFromJson(json);
}

// ─────────────────────────────────────────────
//  REVIEW MODEL
// ─────────────────────────────────────────────
@freezed
class ReviewModel with _$ReviewModel {
  const factory ReviewModel({
    required String id,
    required String orderId,
    required String customerId,
    required String restaurantId,
    String? driverId,
    required double restaurantRating,
    String? restaurantComment,
    double? driverRating,
    String? driverComment,
    @Default([]) List<String> tags,     // fast, tasty, great packaging…
    required DateTime createdAt,
  }) = _ReviewModel;

  factory ReviewModel.fromJson(Map<String, dynamic> json) =>
      _$ReviewModelFromJson(json);
}

// ─────────────────────────────────────────────
//  PROMO CODE MODEL
// ─────────────────────────────────────────────
@freezed
class PromoCodeModel with _$PromoCodeModel {
  const factory PromoCodeModel({
    required String id,
    required String code,
    required String type,           // percent | fixed
    required double value,
    @Default(0.0) double minOrder,
    @Default(double.infinity) double maxDiscount,
    @Default(-1) int usageLimit,    // -1 = unlimited
    @Default(0) int usageCount,
    @Default(true) bool isActive,
    DateTime? expiresAt,
    required DateTime createdAt,
  }) = _PromoCodeModel;

  factory PromoCodeModel.fromJson(Map<String, dynamic> json) =>
      _$PromoCodeModelFromJson(json);
}

// ─────────────────────────────────────────────
//  CHAT MESSAGE
// ─────────────────────────────────────────────
@freezed
class ChatMessage with _$ChatMessage {
  const factory ChatMessage({
    required String id,
    required String content,
    required String role,    // user | assistant
    required DateTime createdAt,
    @Default(false) bool isLoading,
  }) = _ChatMessage;

  factory ChatMessage.fromJson(Map<String, dynamic> json) =>
      _$ChatMessageFromJson(json);
}

// ─────────────────────────────────────────────
//  AI MODELS
// ─────────────────────────────────────────────
@freezed
class AiDriverMatch with _$AiDriverMatch {
  const factory AiDriverMatch({
    required String driverId,
    required double score,
    required String reason,
    required int estimatedPickupMinutes,
    required int estimatedDeliveryMinutes,
  }) = _AiDriverMatch;

  factory AiDriverMatch.fromJson(Map<String, dynamic> json) =>
      _$AiDriverMatchFromJson(json);
}

@freezed
class DemandPrediction with _$DemandPrediction {
  const factory DemandPrediction({
    required String hour,
    required int predictedOrders,
    required double suggestedDeliveryFee,
    required String label,   // calm | normal | busy | very_busy
  }) = _DemandPrediction;

  factory DemandPrediction.fromJson(Map<String, dynamic> json) =>
      _$DemandPredictionFromJson(json);
}
