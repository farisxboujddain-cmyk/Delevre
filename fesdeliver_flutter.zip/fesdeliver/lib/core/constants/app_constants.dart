class AppConstants {
  AppConstants._();

  // App Info
  static const appName    = 'FesDeliver';
  static const appVersion = '1.0.0';
  static const appLocale  = 'ar_MA';

  // Firebase Collections
  static const usersCol       = 'users';
  static const ordersCol      = 'orders';
  static const restaurantsCol = 'restaurants';
  static const menuItemsCol   = 'menuItems';
  static const driversCol     = 'drivers';
  static const walletsCol     = 'wallets';
  static const transactionsCol= 'transactions';
  static const reviewsCol     = 'reviews';
  static const promoCodesCol  = 'promoCodes';
  static const notificationsCol='notifications';
  static const chatsCol       = 'chats';

  // Firestore field names
  static const fieldCreatedAt  = 'createdAt';
  static const fieldUpdatedAt  = 'updatedAt';
  static const fieldStatus     = 'status';
  static const fieldUserId     = 'userId';
  static const fieldDriverId   = 'driverId';
  static const fieldTotal      = 'total';

  // Order Status Flow
  static const statusPending   = 'pending';
  static const statusAccepted  = 'accepted';
  static const statusPreparing = 'preparing';
  static const statusPicked    = 'picked';
  static const statusDelivered = 'delivered';
  static const statusCancelled = 'cancelled';
  static const statusReviewed  = 'reviewed';

  // Payment Methods
  static const payWallet  = 'wallet';
  static const payCard    = 'card';
  static const payCash    = 'cash';
  static const payApplePay= 'apple_pay';
  static const payGooglePay='google_pay';

  // User Roles
  static const roleCustomer = 'customer';
  static const roleMerchant = 'merchant';
  static const roleDriver   = 'driver';
  static const roleAdmin    = 'admin';

  // Shared Prefs Keys
  static const prefThemeMode  = 'theme_mode';
  static const prefUserRole   = 'user_role';
  static const prefOnboarded  = 'onboarded';
  static const prefLang       = 'language';

  // Google Maps
  static const defaultLat  = 34.0331;  // Fes, Morocco
  static const defaultLng  = -5.0003;
  static const defaultZoom = 14.0;

  // Delivery
  static const baseDeliveryFee    = 10.0;
  static const freeDeliveryAmount = 200.0;
  static const maxDeliveryRadius  = 15.0; // km

  // Wallet
  static const minTopUp    = 20.0;
  static const maxTopUp    = 5000.0;
  static const minTransfer = 5.0;

  // AI
  static const geminiModel = 'gemini-pro';
  static const maxChatHistory = 20;

  // Pagination
  static const pageSize = 20;

  // Cache
  static const cacheDuration = Duration(minutes: 5);

  // Animation durations
  static const fastAnim   = Duration(milliseconds: 200);
  static const normalAnim = Duration(milliseconds: 350);
  static const slowAnim   = Duration(milliseconds: 600);
}
