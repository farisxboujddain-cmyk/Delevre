import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import '../constants/app_constants.dart';
import '../models/models.dart';

final aiServiceProvider = Provider<AiService>((ref) => AiService());

class AiService {
  // ── Gemini model instance ──────────────────
  GenerativeModel get _model => GenerativeModel(
    model: 'gemini-1.5-flash',
    apiKey: const String.fromEnvironment('GEMINI_API_KEY'),
    generationConfig: GenerationConfig(
      temperature: 0.7,
      maxOutputTokens: 1000,
      responseMimeType: 'application/json',
    ),
  );

  GenerativeModel get _chatModel => GenerativeModel(
    model: 'gemini-1.5-flash',
    apiKey: const String.fromEnvironment('GEMINI_API_KEY'),
    systemInstruction: Content.system(_chatSystemPrompt),
    generationConfig: GenerationConfig(temperature: 0.8, maxOutputTokens: 500),
  );

  // ─────────────────────────────────────────────
  //  1. AI SMART DRIVER MATCHING
  // ─────────────────────────────────────────────
  Future<AiDriverMatch?> findBestDriver({
    required GeoPoint orderLocation,
    required GeoPoint restaurantLocation,
    required List<Map<String, dynamic>> availableDrivers,
    required String orderType,      // food | grocery | pharmacy
    required double orderWeight,
  }) async {
    if (availableDrivers.isEmpty) return null;

    final prompt = '''
أنت نظام ذكاء اصطناعي لمنصة توصيل FesDeliver في مدينة فاس، المغرب.
مهمتك: اختر أفضل سائق متاح للطلب التالي.

معلومات الطلب:
- موقع المطعم: lat=${restaurantLocation.latitude}, lng=${restaurantLocation.longitude}
- موقع التوصيل: lat=${orderLocation.latitude}, lng=${orderLocation.longitude}
- نوع الطلب: $orderType
- الوزن التقريبي: $orderWeight كغ

السائقون المتاحون:
${availableDrivers.map((d) => '''
  - ID: ${d['id']}, التقييم: ${d['rating']}, 
    الموقع: lat=${d['lat']}, lng=${d['lng']},
    نوع المركبة: ${d['vehicleType']},
    عدد التوصيلات اليوم: ${d['todayDeliveries']}
''').join('\n')}

أعطني الإجابة بـ JSON فقط بهذا الشكل:
{
  "driverId": "...",
  "score": 0.95,
  "reason": "سبب الاختيار بالعربية",
  "estimatedPickupMinutes": 8,
  "estimatedDeliveryMinutes": 18
}
''';

    try {
      final response = await _model.generateContent([Content.text(prompt)]);
      final text = response.text ?? '{}';
      final json = jsonDecode(text.replaceAll('```json', '').replaceAll('```', '').trim());
      return AiDriverMatch.fromJson(json as Map<String, dynamic>);
    } catch (e) {
      return null;
    }
  }

  // ─────────────────────────────────────────────
  //  2. AI DEMAND PREDICTION
  // ─────────────────────────────────────────────
  Future<List<DemandPrediction>> predictDemand({
    required String city,
    required List<Map<String, dynamic>> historicalOrders,
    required DateTime date,
  }) async {
    final dayName = _getDayNameAr(date.weekday);

    final prompt = '''
أنت نظام تنبؤ بالطلب لمنصة FesDeliver في $city.

البيانات التاريخية (آخر 30 يوم، نفس اليوم):
${jsonEncode(historicalOrders)}

اليوم: $dayName ${date.day}/${date.month}/${date.year}

توقع عدد الطلبات ورسوم التوصيل المقترحة لكل ساعة من 8 صباحاً لـ 23 ليلاً.
الرد بـ JSON فقط:
{
  "predictions": [
    {
      "hour": "08:00",
      "predictedOrders": 15,
      "suggestedDeliveryFee": 8.0,
      "label": "calm"
    }
  ]
}
حيث label إما: calm | normal | busy | very_busy
''';

    try {
      final response = await _model.generateContent([Content.text(prompt)]);
      final text = response.text ?? '{"predictions":[]}';
      final json = jsonDecode(text.replaceAll('```json', '').replaceAll('```', '').trim());
      final list = (json['predictions'] as List<dynamic>?) ?? [];
      return list.map((e) => DemandPrediction.fromJson(e as Map<String, dynamic>)).toList();
    } catch (e) {
      return [];
    }
  }

  // ─────────────────────────────────────────────
  //  3. AI ETA CALCULATION
  // ─────────────────────────────────────────────
  Future<int> calculateEta({
    required GeoPoint driverLocation,
    required GeoPoint restaurantLocation,
    required GeoPoint deliveryLocation,
    required int prepTimeMinutes,
    required bool isBusyHour,
  }) async {
    final prompt = '''
احسب وقت التوصيل المتوقع بدقة لمنصة FesDeliver في فاس، المغرب.

السائق: lat=${driverLocation.latitude}, lng=${driverLocation.longitude}
المطعم: lat=${restaurantLocation.latitude}, lng=${restaurantLocation.longitude}
وجهة التوصيل: lat=${deliveryLocation.latitude}, lng=${deliveryLocation.longitude}
وقت التحضير: $prepTimeMinutes دقيقة
وقت ذروة: $isBusyHour

خذ بعين الاعتبار:
- السرعة المتوسطة للدراجة في فاس: 25 كم/ساعة
- في وقت الذروة: 15 كم/ساعة
- ضع 2 دقيقة للتسليم والاستلام

أجب بـ JSON فقط: {"etaMinutes": 22}
''';

    try {
      final response = await _model.generateContent([Content.text(prompt)]);
      final text = response.text ?? '{"etaMinutes": 30}';
      final json = jsonDecode(text.replaceAll('```json', '').replaceAll('```', '').trim());
      return (json['etaMinutes'] as num?)?.toInt() ?? 30;
    } catch (e) {
      // Fallback: simple distance calculation
      return prepTimeMinutes + 20;
    }
  }

  // ─────────────────────────────────────────────
  //  4. AI CHATBOT (multi-turn)
  // ─────────────────────────────────────────────
  ChatSession startChatSession() => _chatModel.startChat();

  Future<String> chat({
    required ChatSession session,
    required String message,
    Map<String, dynamic>? orderContext,
  }) async {
    String fullMessage = message;
    if (orderContext != null) {
      fullMessage = 'سياق الطلب: ${jsonEncode(orderContext)}\n\nالسؤال: $message';
    }

    try {
      final response = await session.sendMessage(Content.text(fullMessage));
      return response.text ?? 'عذراً، لم أفهم سؤالك. هل يمكنك إعادة صياغته؟';
    } catch (e) {
      return 'عذراً، حدث خطأ في الاتصال. حاول مجدداً.';
    }
  }

  // ─────────────────────────────────────────────
  //  5. AI SMART SEARCH (menu recommendations)
  // ─────────────────────────────────────────────
  Future<List<String>> getSmartRecommendations({
    required String userId,
    required List<String> orderHistory,
    required String timeOfDay,
    required String weather,
  }) async {
    final prompt = '''
بناءً على سجل طلبات المستخدم وتفضيلاته، اقترح 3 أطباق أو مطاعم.

سجل الطلبات السابقة: ${orderHistory.join(', ')}
الوقت الحالي: $timeOfDay
الطقس: $weather
المدينة: فاس، المغرب

أجب بـ JSON فقط:
{"recommendations": ["اسم_1", "اسم_2", "اسم_3"]}
''';

    try {
      final response = await _model.generateContent([Content.text(prompt)]);
      final text = response.text ?? '{"recommendations":[]}';
      final json = jsonDecode(text.replaceAll('```json', '').replaceAll('```', '').trim());
      return List<String>.from(json['recommendations'] ?? []);
    } catch (e) {
      return [];
    }
  }

  // ─────────────────────────────────────────────
  //  HELPERS
  // ─────────────────────────────────────────────
  String _getDayNameAr(int weekday) {
    const days = ['الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت', 'الأحد'];
    return days[(weekday - 1).clamp(0, 6)];
  }

  static const String _chatSystemPrompt = '''
أنت مساعد خدمة عملاء ذكي لمنصة FesDeliver، منصة التوصيل الرائدة في مدينة فاس، المغرب.
تحدث دائماً بالعربية الدارجة المغربية المختلطة بالفرنسية.
مهامك:
- مساعدة العملاء في تتبع طلباتهم
- الإجابة عن الأسئلة المتعلقة بالمطاعم والمنيو
- حل مشكلات الدفع والمحفظة
- استقبال الشكاوى وتوجيهها
- شرح كيفية استخدام التطبيق

قواعد:
- ردودك قصيرة ومباشرة (3-4 جمل كحد أقصى)
- كن لطيفاً وودوداً
- إذا لم تعرف الإجابة، قل ذلك وادعُ للتواصل مع الدعم البشري
- لا تعطِ معلومات خاطئة عن الأسعار أو الأوقات
''';
}

// ─────────────────────────────────────────────
//  Gemini Chat Session Provider (per user)
// ─────────────────────────────────────────────
final chatSessionProvider = Provider.autoDispose<ChatSession>((ref) {
  final aiService = ref.watch(aiServiceProvider);
  return aiService.startChatSession();
});
