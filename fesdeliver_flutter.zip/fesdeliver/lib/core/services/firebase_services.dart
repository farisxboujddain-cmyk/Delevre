import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../constants/app_constants.dart';
import '../models/models.dart';

// ─────────────────────────────────────────────
//  Firebase Providers
// ─────────────────────────────────────────────
final firebaseAuthProvider = Provider<FirebaseAuth>(
  (_) => FirebaseAuth.instance,
);

final firestoreProvider = Provider<FirebaseFirestore>(
  (_) => FirebaseFirestore.instance,
);

final storageProvider = Provider<FirebaseStorage>(
  (_) => FirebaseStorage.instance,
);

// ─────────────────────────────────────────────
//  AUTH SERVICE
// ─────────────────────────────────────────────
final authServiceProvider = Provider<AuthService>((ref) {
  return AuthService(
    auth: ref.watch(firebaseAuthProvider),
    firestore: ref.watch(firestoreProvider),
  );
});

class AuthService {
  AuthService({required this.auth, required this.firestore});

  final FirebaseAuth auth;
  final FirebaseFirestore firestore;

  User? get currentUser => auth.currentUser;
  Stream<User?> get authStream => auth.authStateChanges();

  // ── Phone OTP ──────────────────────────────
  Future<void> sendOtp({
    required String phone,
    required Function(String verificationId) onCodeSent,
    required Function(String error) onError,
  }) async {
    await auth.verifyPhoneNumber(
      phoneNumber: phone,
      verificationCompleted: (cred) async {
        await auth.signInWithCredential(cred);
      },
      verificationFailed: (e) => onError(e.message ?? 'فشل إرسال الرمز'),
      codeSent: (id, _) => onCodeSent(id),
      codeAutoRetrievalTimeout: (_) {},
      timeout: const Duration(seconds: 60),
    );
  }

  Future<UserCredential> verifyOtp({
    required String verificationId,
    required String smsCode,
  }) async {
    final cred = PhoneAuthProvider.credential(
      verificationId: verificationId,
      smsCode: smsCode,
    );
    return auth.signInWithCredential(cred);
  }

  // ── Google Sign In ─────────────────────────
  Future<UserCredential?> signInWithGoogle() async {
    final googleUser = await GoogleSignIn().signIn();
    if (googleUser == null) return null;
    final gAuth = await googleUser.authentication;
    final cred = GoogleAuthProvider.credential(
      accessToken: gAuth.accessToken,
      idToken: gAuth.idToken,
    );
    return auth.signInWithCredential(cred);
  }

  // ── Create / Get User Doc ──────────────────
  Future<void> createUserDocument({
    required String uid,
    required String name,
    required String phone,
    required String role,
    String? email,
    String? photoUrl,
  }) async {
    final ref = firestore.collection(AppConstants.usersCol).doc(uid);
    final snap = await ref.get();
    if (!snap.exists) {
      await ref.set({
        'id': uid,
        'name': name,
        'phone': phone,
        'email': email,
        'photoUrl': photoUrl,
        'role': role,
        'isVerified': false,
        'isActive': true,
        'language': 'ar',
        'themeMode': 'dark',
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
      // Create wallet
      await firestore.collection(AppConstants.walletsCol).doc(uid).set({
        'userId': uid,
        'balance': 0.0,
        'loyaltyPoints': 0,
        'isActive': true,
        'updatedAt': FieldValue.serverTimestamp(),
      });
    }
  }

  Future<UserModel?> getUser(String uid) async {
    final snap = await firestore.collection(AppConstants.usersCol).doc(uid).get();
    if (!snap.exists) return null;
    return UserModel.fromFirestore(snap);
  }

  Future<void> updateFcmToken(String uid, String token) async {
    await firestore.collection(AppConstants.usersCol).doc(uid).update({
      'fcmToken': token,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> signOut() async {
    await GoogleSignIn().signOut();
    await auth.signOut();
  }
}

// ─────────────────────────────────────────────
//  ORDER SERVICE
// ─────────────────────────────────────────────
final orderServiceProvider = Provider<OrderService>((ref) {
  return OrderService(firestore: ref.watch(firestoreProvider));
});

class OrderService {
  OrderService({required this.firestore});

  final FirebaseFirestore firestore;

  // Real-time order stream for customer
  Stream<OrderModel?> watchOrder(String orderId) {
    return firestore
        .collection(AppConstants.ordersCol)
        .doc(orderId)
        .snapshots()
        .map((s) => s.exists ? OrderModel.fromFirestore(s) : null);
  }

  // Real-time orders for merchant
  Stream<List<OrderModel>> watchMerchantOrders(String restaurantId) {
    return firestore
        .collection(AppConstants.ordersCol)
        .where('restaurantId', isEqualTo: restaurantId)
        .where('status', whereNotIn: [AppConstants.statusDelivered, AppConstants.statusCancelled])
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((s) => s.docs.map(OrderModel.fromFirestore).toList());
  }

  // Customer order history
  Future<List<OrderModel>> getCustomerOrders(String customerId, {int limit = 20}) async {
    final snap = await firestore
        .collection(AppConstants.ordersCol)
        .where('customerId', isEqualTo: customerId)
        .orderBy('createdAt', descending: true)
        .limit(limit)
        .get();
    return snap.docs.map(OrderModel.fromFirestore).toList();
  }

  // Create order
  Future<String> createOrder(OrderModel order) async {
    final ref = firestore.collection(AppConstants.ordersCol).doc();
    final data = order.toJson();
    data['createdAt'] = FieldValue.serverTimestamp();
    data['updatedAt'] = FieldValue.serverTimestamp();
    await ref.set(data);
    return ref.id;
  }

  // Update order status
  Future<void> updateStatus(String orderId, String status) async {
    final updates = <String, dynamic>{
      'status': status,
      'updatedAt': FieldValue.serverTimestamp(),
    };
    switch (status) {
      case AppConstants.statusAccepted:
        updates['acceptedAt'] = FieldValue.serverTimestamp();
        break;
      case AppConstants.statusPicked:
        updates['pickedAt'] = FieldValue.serverTimestamp();
        break;
      case AppConstants.statusDelivered:
        updates['deliveredAt'] = FieldValue.serverTimestamp();
        break;
    }
    await firestore.collection(AppConstants.ordersCol).doc(orderId).update(updates);
  }

  // Update driver location (called by driver app every 5 sec)
  Future<void> updateDriverLocation(String orderId, GeoPoint location, double heading) async {
    await firestore.collection(AppConstants.ordersCol).doc(orderId).update({
      'driverLocation': location,
      'driverHeading': heading,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  // Cancel order
  Future<void> cancelOrder(String orderId, String reason) async {
    await firestore.collection(AppConstants.ordersCol).doc(orderId).update({
      'status': AppConstants.statusCancelled,
      'cancellationReason': reason,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
}

// ─────────────────────────────────────────────
//  WALLET SERVICE
// ─────────────────────────────────────────────
final walletServiceProvider = Provider<WalletService>((ref) {
  return WalletService(firestore: ref.watch(firestoreProvider));
});

class WalletService {
  WalletService({required this.firestore});

  final FirebaseFirestore firestore;

  Stream<WalletModel> watchWallet(String userId) {
    return firestore
        .collection(AppConstants.walletsCol)
        .doc(userId)
        .snapshots()
        .map((s) => WalletModel.fromJson({...s.data()!, 'userId': userId}));
  }

  Stream<List<TransactionModel>> watchTransactions(String userId) {
    return firestore
        .collection(AppConstants.transactionsCol)
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .limit(50)
        .snapshots()
        .map((s) => s.docs.map((d) => TransactionModel.fromJson({...d.data(), 'id': d.id})).toList());
  }

  // Top-up wallet (called after Stripe payment confirmation)
  Future<void> topUp(String userId, double amount, String stripePaymentId) async {
    final batch = firestore.batch();

    // Update balance
    final walletRef = firestore.collection(AppConstants.walletsCol).doc(userId);
    batch.update(walletRef, {
      'balance': FieldValue.increment(amount),
      'updatedAt': FieldValue.serverTimestamp(),
    });

    // Transaction record
    final txRef = firestore.collection(AppConstants.transactionsCol).doc();
    batch.set(txRef, {
      'userId': userId,
      'type': 'credit',
      'amount': amount,
      'description': 'تعبئة المحفظة',
      'referenceId': stripePaymentId,
      'status': 'completed',
      'createdAt': FieldValue.serverTimestamp(),
    });

    await batch.commit();
  }

  // Transfer between users
  Future<void> transfer({
    required String fromUserId,
    required String toUserId,
    required double amount,
    String? note,
  }) async {
    // Verify sender has enough balance
    final senderWallet = await firestore.collection(AppConstants.walletsCol).doc(fromUserId).get();
    final balance = (senderWallet.data()?['balance'] ?? 0.0) as double;
    if (balance < amount) throw Exception('رصيد غير كافٍ');

    final batch = firestore.batch();
    final transferId = firestore.collection('_').doc().id;

    // Deduct from sender
    batch.update(firestore.collection(AppConstants.walletsCol).doc(fromUserId), {
      'balance': FieldValue.increment(-amount),
      'updatedAt': FieldValue.serverTimestamp(),
    });

    // Add to recipient
    batch.update(firestore.collection(AppConstants.walletsCol).doc(toUserId), {
      'balance': FieldValue.increment(amount),
      'updatedAt': FieldValue.serverTimestamp(),
    });

    // Sender transaction
    final txRef1 = firestore.collection(AppConstants.transactionsCol).doc();
    batch.set(txRef1, {
      'userId': fromUserId,
      'type': 'transfer_out',
      'amount': amount,
      'description': note ?? 'تحويل',
      'referenceId': transferId,
      'toUserId': toUserId,
      'status': 'completed',
      'createdAt': FieldValue.serverTimestamp(),
    });

    // Recipient transaction
    final txRef2 = firestore.collection(AppConstants.transactionsCol).doc();
    batch.set(txRef2, {
      'userId': toUserId,
      'type': 'transfer_in',
      'amount': amount,
      'description': note ?? 'تحويل مستلم',
      'referenceId': transferId,
      'fromUserId': fromUserId,
      'status': 'completed',
      'createdAt': FieldValue.serverTimestamp(),
    });

    await batch.commit();
  }

  // Deduct for order payment
  Future<void> deductForOrder(String userId, double amount, String orderId) async {
    final batch = firestore.batch();

    batch.update(firestore.collection(AppConstants.walletsCol).doc(userId), {
      'balance': FieldValue.increment(-amount),
      'updatedAt': FieldValue.serverTimestamp(),
    });

    final txRef = firestore.collection(AppConstants.transactionsCol).doc();
    batch.set(txRef, {
      'userId': userId,
      'type': 'debit',
      'amount': amount,
      'description': 'دفع طلب',
      'referenceId': orderId,
      'status': 'completed',
      'createdAt': FieldValue.serverTimestamp(),
    });

    await batch.commit();
  }
}

// ─────────────────────────────────────────────
//  STORAGE SERVICE
// ─────────────────────────────────────────────
final storageServiceProvider = Provider<StorageService>((ref) {
  return StorageService(storage: ref.watch(storageProvider));
});

class StorageService {
  StorageService({required this.storage});

  final FirebaseStorage storage;

  Future<String> uploadImage(File file, String path) async {
    final ref = storage.ref().child(path);
    final task = await ref.putFile(file);
    return task.ref.getDownloadURL();
  }

  Future<String> uploadRestaurantCover(String restaurantId, File file) {
    return uploadImage(file, 'restaurants/$restaurantId/cover.jpg');
  }

  Future<String> uploadMenuItemImage(String itemId, File file) {
    return uploadImage(file, 'menu_items/$itemId.jpg');
  }

  Future<String> uploadUserPhoto(String userId, File file) {
    return uploadImage(file, 'users/$userId/profile.jpg');
  }

  Future<String> uploadDriverDoc(String driverId, String docType, File file) {
    return uploadImage(file, 'drivers/$driverId/$docType.jpg');
  }

  Future<void> deleteFile(String url) async {
    try {
      final ref = storage.refFromURL(url);
      await ref.delete();
    } catch (_) {}
  }
}
