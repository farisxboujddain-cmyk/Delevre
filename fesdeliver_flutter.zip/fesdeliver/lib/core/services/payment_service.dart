import 'package:flutter/material.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final paymentServiceProvider = Provider<PaymentService>((ref) => PaymentService());

class PaymentService {
  static void initialize(String publishableKey) {
    Stripe.publishableKey = publishableKey;
    Stripe.merchantIdentifier = 'merchant.com.fesdeliver';
    Stripe.urlScheme = 'fesdeliver';
  }

  // ── Card / Apple Pay / Google Pay ─────────────
  Future<PaymentResult> processPayment({
    required double amount,
    required String currency,
    required String userId,
    required String orderId,
    String? description,
  }) async {
    try {
      // 1. Call Cloud Function to create PaymentIntent
      final callable = FirebaseFunctions.instance.httpsCallable('createPaymentIntent');
      final result = await callable.call({
        'amount': (amount * 100).toInt(), // Stripe uses smallest currency unit
        'currency': currency,
        'userId': userId,
        'orderId': orderId,
        'description': description ?? 'FesDeliver Order',
      });

      final clientSecret = result.data['clientSecret'] as String;

      // 2. Present payment sheet
      await Stripe.instance.initPaymentSheet(
        paymentSheetParameters: SetupPaymentSheetParameters(
          paymentIntentClientSecret: clientSecret,
          merchantDisplayName: 'FesDeliver',
          style: ThemeMode.dark,
          appearance: const PaymentSheetAppearance(
            colors: PaymentSheetAppearanceColors(
              primary: Color(0xFF1B6B3A),
              background: Color(0xFF132A1C),
              componentBackground: Color(0xFF1A3524),
              primaryText: Color(0xFFF5EDD8),
              secondaryText: Color(0xFF8BA899),
            ),
          ),
          applePay: const PaymentSheetApplePay(merchantCountryCode: 'MA'),
          googlePay: const PaymentSheetGooglePay(
            merchantCountryCode: 'MA',
            testEnv: true,
          ),
        ),
      );

      await Stripe.instance.presentPaymentSheet();

      return PaymentResult(
        success: true,
        paymentIntentId: clientSecret.split('_secret')[0],
      );
    } on StripeException catch (e) {
      return PaymentResult(
        success: false,
        error: e.error.localizedMessage ?? 'فشل الدفع',
      );
    } catch (e) {
      return PaymentResult(success: false, error: e.toString());
    }
  }

  // ── Wallet top-up via Stripe ───────────────
  Future<PaymentResult> topUpWallet({
    required String userId,
    required double amount,
  }) async {
    return processPayment(
      amount: amount,
      currency: 'mad',
      userId: userId,
      orderId: 'wallet_topup_${DateTime.now().millisecondsSinceEpoch}',
      description: 'تعبئة محفظة FesDeliver',
    );
  }

  // ── Refund ────────────────────────────────
  Future<bool> refundPayment(String paymentIntentId, double amount) async {
    try {
      final callable = FirebaseFunctions.instance.httpsCallable('refundPayment');
      final result = await callable.call({
        'paymentIntentId': paymentIntentId,
        'amount': (amount * 100).toInt(),
      });
      return result.data['success'] == true;
    } catch (_) {
      return false;
    }
  }
}

class PaymentResult {
  final bool success;
  final String? paymentIntentId;
  final String? error;

  PaymentResult({required this.success, this.paymentIntentId, this.error});
}
