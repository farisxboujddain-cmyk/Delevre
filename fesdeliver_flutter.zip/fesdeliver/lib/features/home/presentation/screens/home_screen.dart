import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/providers/app_providers.dart';
import '../../../../core/router/app_router.dart';
import '../../../../core/models/models.dart';
import '../widgets/restaurant_card.dart';
import '../widgets/ai_suggestion_banner.dart';
import '../widgets/active_order_banner.dart';
import '../widgets/category_filter.dart';
import '../providers/home_provider.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  final _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = ref.watch(themeModeProvider);
    final currentUser = ref.watch(currentUserProvider).value;
    final homeState = ref.watch(homeProvider);
    final cartCount = ref.watch(cartCountProvider);

    return Scaffold(
      backgroundColor: isDark ? FesColors.bgDark : FesColors.bgLight,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          // ── App Bar ──────────────────────────
          SliverAppBar(
            expandedHeight: 140,
            floating: true,
            pinned: true,
            snap: true,
            backgroundColor: isDark ? FesColors.cardDark : FesColors.cardLight,
            elevation: 0,
            flexibleSpace: FlexibleSpaceBar(
              background: _buildHeader(context, currentUser, cartCount, isDark),
            ),
            bottom: PreferredSize(
              preferredSize: const Size.fromHeight(60),
              child: _buildSearchBar(isDark),
            ),
          ),

          SliverPadding(
            padding: const EdgeInsets.all(16),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                // ── Active Order Banner ───────
                const ActiveOrderBanner(),
                const SizedBox(height: 16),

                // ── AI Suggestions ────────────
                const AiSuggestionBanner(),
                const SizedBox(height: 16),

                // ── Category Filter ───────────
                CategoryFilter(
                  selected: homeState.selectedCategory,
                  onSelect: (cat) => ref.read(homeProvider.notifier).selectCategory(cat),
                ),
                const SizedBox(height: 20),

                // ── Section Title ─────────────
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'المطاعم القريبة',
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                    TextButton(
                      onPressed: () {},
                      child: const Text('عرض الكل', style: TextStyle(color: FesColors.green)),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
              ]),
            ),
          ),

          // ── Restaurant List ───────────────
          homeState.isLoading
              ? const SliverFillRemaining(child: Center(child: CircularProgressIndicator()))
              : SliverPadding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                  sliver: SliverList.separated(
                    itemCount: homeState.filteredRestaurants.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 14),
                    itemBuilder: (_, i) => RestaurantCard(
                      restaurant: homeState.filteredRestaurants[i],
                      onTap: () => context.push(
                        '/restaurant/${homeState.filteredRestaurants[i].id}',
                      ),
                    ),
                  ),
                ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context, UserModel? user, int cartCount, bool isDark) {
    return Container(
      decoration: BoxDecoration(
        color: isDark ? FesColors.cardDark : FesColors.cardLight,
        gradient: isDark
            ? LinearGradient(
                colors: [FesColors.greenDark.withOpacity(0.3), FesColors.cardDark],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              )
            : null,
      ),
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 8,
        left: 20,
        right: 20,
        bottom: 8,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    const Icon(Icons.location_on, color: FesColors.gold, size: 16),
                    const SizedBox(width: 4),
                    Text(
                      'فاس، المغرب',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                RichText(
                  text: TextSpan(
                    style: Theme.of(context).textTheme.headlineLarge,
                    children: [
                      const TextSpan(text: 'مرحباً، '),
                      TextSpan(
                        text: user?.name.split(' ').first ?? 'صديقي',
                        style: const TextStyle(color: FesColors.gold),
                      ),
                      const TextSpan(text: ' 👋'),
                    ],
                  ),
                ),
              ],
            ),
          ),
          // Cart button
          _IconButton(
            onTap: () => context.push(AppRoutes.cart),
            icon: Icons.shopping_cart_rounded,
            badge: cartCount,
          ),
          const SizedBox(width: 10),
          // Theme toggle
          _IconButton(
            onTap: () => ref.read(themeModeProvider.notifier).toggle(),
            icon: ref.watch(themeModeProvider)
                ? Icons.light_mode_rounded
                : Icons.dark_mode_rounded,
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar(bool isDark) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
      child: TextField(
        controller: _searchController,
        onChanged: (q) => ref.read(homeProvider.notifier).search(q),
        textAlign: TextAlign.right,
        decoration: InputDecoration(
          hintText: 'ابحث عن مطعم أو طبق...',
          prefixIcon: const Icon(Icons.search_rounded, color: FesColors.textMutedDark),
          suffixIcon: _searchController.text.isNotEmpty
              ? IconButton(
                  icon: const Icon(Icons.clear, size: 18),
                  onPressed: () {
                    _searchController.clear();
                    ref.read(homeProvider.notifier).search('');
                  },
                )
              : null,
          filled: true,
          fillColor: isDark ? FesColors.cardDark : FesColors.cardLight,
          contentPadding: const EdgeInsets.symmetric(vertical: 14),
        ),
      ),
    );
  }
}

class _IconButton extends StatelessWidget {
  const _IconButton({required this.onTap, required this.icon, this.badge = 0});

  final VoidCallback onTap;
  final IconData icon;
  final int badge;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: FesColors.cardLightDark,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: FesColors.cardLightDark),
            ),
            child: Icon(icon, color: FesColors.textDark, size: 22),
          ),
          if (badge > 0)
            Positioned(
              top: -5,
              left: -5,
              child: Container(
                width: 18,
                height: 18,
                decoration: const BoxDecoration(color: FesColors.gold, shape: BoxShape.circle),
                child: Center(
                  child: Text(
                    '$badge',
                    style: const TextStyle(color: FesColors.bgDark, fontSize: 10, fontWeight: FontWeight.w800),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
