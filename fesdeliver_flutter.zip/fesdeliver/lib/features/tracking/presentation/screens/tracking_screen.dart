import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/providers/app_providers.dart';
import '../../../../core/models/models.dart';
import '../../../../core/constants/app_constants.dart';

class TrackingScreen extends ConsumerStatefulWidget {
  const TrackingScreen({required this.orderId, super.key});
  final String orderId;

  @override
  ConsumerState<TrackingScreen> createState() => _TrackingScreenState();
}

class _TrackingScreenState extends ConsumerState<TrackingScreen>
    with SingleTickerProviderStateMixin {
  GoogleMapController? _mapController;
  late AnimationController _pulseController;
  final Set<Marker> _markers = {};
  final Set<Polyline> _polylines = {};

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    // Set the active order
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(activeOrderIdProvider.notifier).state = widget.orderId;
    });
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _mapController?.dispose();
    super.dispose();
  }

  void _updateMap(OrderModel order) {
    _markers.clear();

    // Driver marker
    if (order.driverLocation != null) {
      _markers.add(Marker(
        markerId: const MarkerId('driver'),
        position: LatLng(order.driverLocation!.latitude, order.driverLocation!.longitude),
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
        infoWindow: const InfoWindow(title: 'السائق'),
      ));

      // Animate camera to driver
      _mapController?.animateCamera(
        CameraUpdate.newLatLng(
          LatLng(order.driverLocation!.latitude, order.driverLocation!.longitude),
        ),
      );
    }

    // Destination marker
    _markers.add(Marker(
      markerId: const MarkerId('destination'),
      position: LatLng(order.deliveryLocation.latitude, order.deliveryLocation.longitude),
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
      infoWindow: const InfoWindow(title: 'وجهة التوصيل'),
    ));

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final orderAsync = ref.watch(activeOrderProvider);

    return Scaffold(
      backgroundColor: FesColors.bgDark,
      body: orderAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, __) => Center(child: Text('خطأ: $e')),
        data: (order) {
          if (order != null) _updateMap(order);
          return _buildBody(context, order);
        },
      ),
    );
  }

  Widget _buildBody(BuildContext context, OrderModel? order) {
    return Stack(
      children: [
        // ── Map ────────────────────────────────
        GoogleMap(
          onMapCreated: (ctrl) => _mapController = ctrl,
          initialCameraPosition: CameraPosition(
            target: LatLng(
              order?.driverLocation?.latitude ?? AppConstants.defaultLat,
              order?.driverLocation?.longitude ?? AppConstants.defaultLng,
            ),
            zoom: AppConstants.defaultZoom,
          ),
          markers: _markers,
          polylines: _polylines,
          myLocationEnabled: true,
          myLocationButtonEnabled: false,
          zoomControlsEnabled: false,
          mapToolbarEnabled: false,
          style: _darkMapStyle,
        ),

        // ── Top bar ───────────────────────────
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                _MapButton(
                  icon: Icons.arrow_back_rounded,
                  onTap: () => context.pop(),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.7),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: FesColors.cardLightDark),
                  ),
                  child: Text(
                    '#${widget.orderId.substring(0, 8).toUpperCase()}',
                    style: const TextStyle(color: FesColors.textDark, fontSize: 13, fontFamily: 'Cairo'),
                  ),
                ),
                const SizedBox(width: 8),
                _MapButton(icon: Icons.my_location_rounded, onTap: () {
                  if (order?.driverLocation != null) {
                    _mapController?.animateCamera(
                      CameraUpdate.newLatLng(
                        LatLng(order!.driverLocation!.latitude, order.driverLocation!.longitude),
                      ),
                    );
                  }
                }),
              ],
            ),
          ),
        ),

        // ── Bottom sheet ──────────────────────
        Positioned(
          bottom: 0,
          left: 0,
          right: 0,
          child: _BottomSheet(order: order),
        ),
      ],
    );
  }
}

class _BottomSheet extends ConsumerWidget {
  const _BottomSheet({required this.order});
  final OrderModel? order;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Container(
      decoration: const BoxDecoration(
        color: FesColors.cardDark,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      padding: EdgeInsets.only(
        top: 20,
        left: 20,
        right: 20,
        bottom: MediaQuery.of(context).padding.bottom + 16,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Handle
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: FesColors.cardLightDark,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 20),

          // ETA + Status
          Row(
            children: [
              Expanded(
                child: _InfoCard(
                  icon: Icons.schedule_rounded,
                  label: 'الوصول المتوقع',
                  value: '${order?.estimatedMinutes ?? '--'} دق',
                  color: FesColors.gold,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _InfoCard(
                  icon: Icons.inventory_2_rounded,
                  label: 'الحالة',
                  value: _statusLabel(order?.status),
                  color: FesColors.success,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Status timeline
          _StatusTimeline(currentStatus: order?.status ?? AppConstants.statusPending),
          const SizedBox(height: 20),

          // Driver card
          if (order?.driverId != null)
            _DriverCard(orderId: order!.id, driverId: order!.driverId!),
        ],
      ),
    );
  }

  String _statusLabel(String? status) {
    switch (status) {
      case AppConstants.statusPending:    return 'في الانتظار';
      case AppConstants.statusAccepted:   return 'مقبول';
      case AppConstants.statusPreparing:  return 'يتحضر';
      case AppConstants.statusPicked:     return 'في الطريق';
      case AppConstants.statusDelivered:  return 'تم التوصيل';
      case AppConstants.statusCancelled:  return 'ملغى';
      default: return '--';
    }
  }
}

class _StatusTimeline extends StatelessWidget {
  const _StatusTimeline({required this.currentStatus});
  final String currentStatus;

  static const _steps = [
    (AppConstants.statusPending,   'تأكيد',     Icons.hourglass_top_rounded),
    (AppConstants.statusAccepted,  'قُبِل',      Icons.check_circle_outline_rounded),
    (AppConstants.statusPreparing, 'يتحضر',     Icons.restaurant_rounded),
    (AppConstants.statusPicked,    'في الطريق', Icons.two_wheeler_rounded),
    (AppConstants.statusDelivered, 'وصل',       Icons.celebration_rounded),
  ];

  int get _currentIndex => _steps.indexWhere((s) => s.$1 == currentStatus);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: List.generate(_steps.length, (i) {
        final isCompleted = i <= _currentIndex;
        final isCurrent = i == _currentIndex;
        final isLast = i == _steps.length - 1;

        return Expanded(
          child: Row(
            children: [
              Expanded(
                child: Column(
                  children: [
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      width: isCurrent ? 36 : 30,
                      height: isCurrent ? 36 : 30,
                      decoration: BoxDecoration(
                        color: isCompleted
                            ? (isCurrent ? FesColors.gold : FesColors.green)
                            : FesColors.cardLightDark,
                        shape: BoxShape.circle,
                        boxShadow: isCurrent
                            ? [BoxShadow(color: FesColors.gold.withOpacity(0.4), blurRadius: 10)]
                            : null,
                      ),
                      child: Icon(
                        _steps[i].$3,
                        color: isCompleted ? Colors.white : FesColors.textMutedDark,
                        size: isCurrent ? 18 : 15,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _steps[i].$2,
                      style: TextStyle(
                        fontSize: 9,
                        color: isCompleted ? FesColors.textDark : FesColors.textMutedDark,
                        fontWeight: isCurrent ? FontWeight.w700 : FontWeight.w400,
                        fontFamily: 'Cairo',
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
              if (!isLast)
                Expanded(
                  child: Container(
                    height: 2,
                    color: i < _currentIndex ? FesColors.green : FesColors.cardLightDark,
                  ),
                ),
            ],
          ),
        );
      }),
    );
  }
}

class _DriverCard extends StatelessWidget {
  const _DriverCard({required this.orderId, required this.driverId});
  final String orderId;
  final String driverId;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: FesColors.cardLightDark,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 26,
            backgroundColor: FesColors.green,
            child: const Icon(Icons.person, color: Colors.white, size: 28),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'محمد أمين',
                  style: TextStyle(color: FesColors.textDark, fontSize: 15, fontWeight: FontWeight.w700, fontFamily: 'Cairo'),
                ),
                Row(
                  children: [
                    const Icon(Icons.star_rounded, color: FesColors.gold, size: 14),
                    const Text(' 4.9', style: TextStyle(color: FesColors.textDark, fontSize: 12, fontFamily: 'Cairo')),
                    const Text(' • 245 رحلة', style: TextStyle(color: FesColors.textMutedDark, fontSize: 12, fontFamily: 'Cairo')),
                  ],
                ),
                const Text(
                  '✨ AI Smart Match — أفضل سائق في المنطقة',
                  style: TextStyle(color: FesColors.gold, fontSize: 11, fontFamily: 'Cairo'),
                ),
              ],
            ),
          ),
          Row(
            children: [
              _DriverActionBtn(icon: Icons.phone_rounded, color: FesColors.green, onTap: () {}),
              const SizedBox(width: 8),
              _DriverActionBtn(icon: Icons.chat_bubble_rounded, color: FesColors.info, onTap: () {}),
            ],
          ),
        ],
      ),
    );
  }
}

class _DriverActionBtn extends StatelessWidget {
  const _DriverActionBtn({required this.icon, required this.color, required this.onTap});
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(icon, color: color, size: 18),
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.icon, required this.label, required this.value, required this.color});
  final IconData icon;
  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: TextStyle(color: FesColors.textMutedDark, fontSize: 11, fontFamily: 'Cairo')),
              Text(value, style: TextStyle(color: color, fontSize: 16, fontWeight: FontWeight.w800, fontFamily: 'Cairo')),
            ],
          ),
        ],
      ),
    );
  }
}

class _MapButton extends StatelessWidget {
  const _MapButton({required this.icon, required this.onTap});
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.7),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(icon, color: Colors.white, size: 20),
      ),
    );
  }
}

// Dark map style JSON
const _darkMapStyle = '''
[
  {"elementType": "geometry", "stylers": [{"color": "#0D1F14"}]},
  {"elementType": "labels.text.fill", "stylers": [{"color": "#8BA899"}]},
  {"elementType": "labels.text.stroke", "stylers": [{"color": "#0D1F14"}]},
  {"featureType": "road", "elementType": "geometry", "stylers": [{"color": "#132A1C"}]},
  {"featureType": "road.arterial", "elementType": "geometry", "stylers": [{"color": "#1A3524"}]},
  {"featureType": "road.highway", "elementType": "geometry", "stylers": [{"color": "#1B6B3A"}]},
  {"featureType": "water", "elementType": "geometry", "stylers": [{"color": "#0F2318"}]},
  {"featureType": "poi", "elementType": "geometry", "stylers": [{"color": "#132A1C"}]},
  {"featureType": "transit", "elementType": "geometry", "stylers": [{"color": "#0F2318"}]}
]
''';
