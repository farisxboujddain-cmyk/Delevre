import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/providers/app_providers.dart';
import '../../../../core/services/ai_service.dart';
import '../../../../core/models/models.dart';

class AdminDashboardScreen extends ConsumerStatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  ConsumerState<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends ConsumerState<AdminDashboardScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  List<DemandPrediction> _predictions = [];
  bool _loadingPredictions = true;

  final _stats = [
    _Stat('طلبات اليوم', '347', '+12%', Icons.inventory_2_rounded, FesColors.green),
    _Stat('الإيرادات', '12,480 د.م.', '+8%', Icons.payments_rounded, FesColors.gold),
    _Stat('سائقون نشطون', '28', '+2', Icons.two_wheeler_rounded, FesColors.info),
    _Stat('المطاعم', '64', '+3', Icons.storefront_rounded, FesColors.warning),
    _Stat('متوسط ETA', '24 دق', '-3%', Icons.schedule_rounded, FesColors.success),
    _Stat('تقييم المنصة', '4.7 ★', '+0.1', Icons.star_rounded, FesColors.gold),
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _loadPredictions();
  }

  Future<void> _loadPredictions() async {
    final ai = ref.read(aiServiceProvider);
    final results = await ai.predictDemand(
      city: 'فاس',
      historicalOrders: [], // would be real data
      date: DateTime.now(),
    );
    // Fallback mock data if AI fails
    if (results.isEmpty) {
      _predictions = List.generate(16, (i) {
        final hour = i + 8;
        final orders = [10, 15, 20, 35, 55, 90, 100, 85, 60, 40, 50, 70, 80, 55, 35, 20][i];
        return DemandPrediction(
          hour: '$hour:00',
          predictedOrders: orders,
          suggestedDeliveryFee: orders > 70 ? 15.0 : 10.0,
          label: orders > 80 ? 'very_busy' : orders > 60 ? 'busy' : orders > 30 ? 'normal' : 'calm',
        );
      });
    } else {
      _predictions = results;
    }
    setState(() => _loadingPredictions = false);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: FesColors.bgDark,
      appBar: AppBar(
        backgroundColor: FesColors.cardDark,
        title: RichText(
          text: const TextSpan(
            style: TextStyle(fontSize: 20, fontFamily: 'Cairo', fontWeight: FontWeight.w900),
            children: [
              TextSpan(text: 'Fes', style: TextStyle(color: FesColors.textDark)),
              TextSpan(text: 'Deliver', style: TextStyle(color: FesColors.gold)),
              TextSpan(text: ' Admin', style: TextStyle(color: FesColors.textMutedDark, fontSize: 14, fontWeight: FontWeight.w400)),
            ],
          ),
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 16),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: FesColors.success.withOpacity(0.15),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: FesColors.success.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                Container(width: 8, height: 8, decoration: const BoxDecoration(color: FesColors.success, shape: BoxShape.circle)),
                const SizedBox(width: 6),
                const Text('مباشر', style: TextStyle(color: FesColors.success, fontSize: 12, fontFamily: 'Cairo')),
              ],
            ),
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: FesColors.green,
          labelColor: FesColors.textDark,
          unselectedLabelColor: FesColors.textMutedDark,
          labelStyle: const TextStyle(fontSize: 12, fontFamily: 'Cairo', fontWeight: FontWeight.w700),
          tabs: const [
            Tab(text: 'نظرة عامة'),
            Tab(text: 'AI التنبؤ'),
            Tab(text: 'الطلبات'),
            Tab(text: 'السائقون'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _OverviewTab(stats: _stats),
          _AIPredictionTab(predictions: _predictions, loading: _loadingPredictions),
          const _OrdersTab(),
          const _DriversTab(),
        ],
      ),
    );
  }
}

class _OverviewTab extends StatelessWidget {
  const _OverviewTab({required this.stats});
  final List<_Stat> stats;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Stats grid
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.5,
            ),
            itemCount: stats.length,
            itemBuilder: (_, i) => _StatCard(stat: stats[i]),
          ),

          const SizedBox(height: 24),
          const Text('تنبيهات الذكاء الاصطناعي', style: TextStyle(color: FesColors.textDark, fontSize: 16, fontWeight: FontWeight.w700, fontFamily: 'Cairo')),
          const SizedBox(height: 12),

          // AI Insights
          ...[
            _AiAlert('الذروة: غداً 12:00-14:00 — اقتراح: أضف 5 سائقين', Icons.trending_up_rounded, FesColors.danger),
            _AiAlert('المدينة القديمة: متوسط ETA 28 دق — أعلى من المعتاد', Icons.warning_rounded, FesColors.warning),
            _AiAlert('مطعم فاس الأصيل: تقييم ممتاز هذا الأسبوع ⭐', Icons.star_rounded, FesColors.success),
          ].map((alert) => Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: FesColors.cardDark,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: alert.color.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  Icon(alert.icon, color: alert.color, size: 20),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(alert.text, style: const TextStyle(color: FesColors.textDark, fontSize: 13, fontFamily: 'Cairo')),
                  ),
                ],
              ),
            ),
          )),
        ],
      ),
    );
  }
}

class _AIPredictionTab extends StatelessWidget {
  const _AIPredictionTab({required this.predictions, required this.loading});
  final List<DemandPrediction> predictions;
  final bool loading;

  Color _barColor(String label) {
    switch (label) {
      case 'very_busy': return FesColors.danger;
      case 'busy': return FesColors.warning;
      case 'normal': return FesColors.green;
      default: return FesColors.info;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());

    final maxOrders = predictions.fold<int>(0, (max, p) => p.predictedOrders > max ? p.predictedOrders : max);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [FesColors.greenDark.withOpacity(0.5), FesColors.cardDark],
              ),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: FesColors.gold.withOpacity(0.3)),
            ),
            child: const Row(
              children: [
                Text('✨', style: TextStyle(fontSize: 24)),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'AI Demand Prediction',
                        style: TextStyle(color: FesColors.gold, fontSize: 15, fontWeight: FontWeight.w700, fontFamily: 'Cairo'),
                      ),
                      Text(
                        'توقعات الطلب لليوم بناءً على البيانات التاريخية',
                        style: TextStyle(color: FesColors.textMutedDark, fontSize: 12, fontFamily: 'Cairo'),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          // Bar chart
          SizedBox(
            height: 200,
            child: BarChart(
              BarChartData(
                alignment: BarChartAlignment.spaceAround,
                maxY: maxOrders.toDouble() * 1.2,
                barTouchData: BarTouchData(enabled: true),
                titlesData: FlTitlesData(
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (value, _) {
                        final i = value.toInt();
                        if (i >= predictions.length) return const SizedBox();
                        return Text(
                          predictions[i].hour.split(':')[0],
                          style: const TextStyle(color: FesColors.textMutedDark, fontSize: 10, fontFamily: 'Cairo'),
                        );
                      },
                    ),
                  ),
                  leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                ),
                gridData: FlGridData(
                  show: true,
                  getDrawingHorizontalLine: (_) => FlLine(
                    color: FesColors.cardLightDark,
                    strokeWidth: 1,
                  ),
                  drawVerticalLine: false,
                ),
                borderData: FlBorderData(show: false),
                barGroups: predictions.asMap().entries.map((e) => BarChartGroupData(
                  x: e.key,
                  barRods: [
                    BarChartRodData(
                      toY: e.value.predictedOrders.toDouble(),
                      color: _barColor(e.value.label),
                      width: 14,
                      borderRadius: const BorderRadius.vertical(top: Radius.circular(6)),
                    ),
                  ],
                )).toList(),
              ),
            ),
          ),

          const SizedBox(height: 20),

          // Legend
          Wrap(
            spacing: 16,
            children: [
              _Legend('هادئ', FesColors.info),
              _Legend('عادي', FesColors.green),
              _Legend('مزدحم', FesColors.warning),
              _Legend('ذروة', FesColors.danger),
            ],
          ),

          const SizedBox(height: 24),
          const Text('رسوم التوصيل المقترحة', style: TextStyle(color: FesColors.textDark, fontSize: 15, fontWeight: FontWeight.w700, fontFamily: 'Cairo')),
          const SizedBox(height: 12),

          // Suggested fees list
          ...predictions.where((p) => p.label == 'busy' || p.label == 'very_busy').map((p) =>
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  color: FesColors.cardDark,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: FesColors.warning.withOpacity(0.3)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(p.hour, style: const TextStyle(color: FesColors.textDark, fontFamily: 'Cairo')),
                    Text('${p.predictedOrders} طلب', style: const TextStyle(color: FesColors.textMutedDark, fontFamily: 'Cairo')),
                    Text('${p.suggestedDeliveryFee.toStringAsFixed(0)} د.م.', style: const TextStyle(color: FesColors.gold, fontWeight: FontWeight.w700, fontFamily: 'Cairo')),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

Widget _Legend(String label, Color color) => Row(
  mainAxisSize: MainAxisSize.min,
  children: [
    Container(width: 12, height: 12, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(3))),
    const SizedBox(width: 4),
    Text(label, style: const TextStyle(color: FesColors.textMutedDark, fontSize: 12, fontFamily: 'Cairo')),
  ],
);

class _OrdersTab extends StatelessWidget {
  const _OrdersTab();

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: 10,
      itemBuilder: (_, i) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: FesColors.cardDark,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: FesColors.green.withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.inventory_2_rounded, color: FesColors.green, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('ORD-28${50 + i}', style: const TextStyle(color: FesColors.textDark, fontWeight: FontWeight.w700, fontFamily: 'Cairo')),
                  Text('مطعم فاس الأصيل • 85 د.م.', style: const TextStyle(color: FesColors.textMutedDark, fontSize: 12, fontFamily: 'Cairo')),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: FesColors.green.withOpacity(0.15),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Text('يتحضر', style: TextStyle(color: FesColors.green, fontSize: 11, fontFamily: 'Cairo')),
            ),
          ],
        ),
      ),
    );
  }
}

class _DriversTab extends StatelessWidget {
  const _DriversTab();

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: 8,
      itemBuilder: (_, i) {
        final isOnline = i < 5;
        return Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: FesColors.cardDark,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: isOnline ? FesColors.success.withOpacity(0.2) : FesColors.cardLightDark),
          ),
          child: Row(
            children: [
              Stack(
                children: [
                  CircleAvatar(
                    radius: 22,
                    backgroundColor: FesColors.cardLightDark,
                    child: const Icon(Icons.person, color: FesColors.textMutedDark),
                  ),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: Container(
                      width: 12,
                      height: 12,
                      decoration: BoxDecoration(
                        color: isOnline ? FesColors.success : FesColors.textMutedDark,
                        shape: BoxShape.circle,
                        border: Border.all(color: FesColors.cardDark, width: 2),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('سائق ${i + 1}', style: const TextStyle(color: FesColors.textDark, fontWeight: FontWeight.w700, fontFamily: 'Cairo')),
                    Row(
                      children: [
                        const Icon(Icons.star_rounded, color: FesColors.gold, size: 12),
                        Text(' 4.${7 + (i % 3)} • ${20 + i * 3} توصيل اليوم', style: const TextStyle(color: FesColors.textMutedDark, fontSize: 11, fontFamily: 'Cairo')),
                      ],
                    ),
                  ],
                ),
              ),
              Text(
                isOnline ? 'نشط' : 'غير متصل',
                style: TextStyle(color: isOnline ? FesColors.success : FesColors.textMutedDark, fontSize: 12, fontFamily: 'Cairo'),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({required this.stat});
  final _Stat stat;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: FesColors.cardDark,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: stat.color.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Icon(stat.icon, color: stat.color, size: 22),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: FesColors.success.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(stat.change, style: const TextStyle(color: FesColors.success, fontSize: 11, fontFamily: 'Cairo')),
              ),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(stat.value, style: TextStyle(color: stat.color, fontSize: 18, fontWeight: FontWeight.w800, fontFamily: 'Cairo')),
              Text(stat.label, style: const TextStyle(color: FesColors.textMutedDark, fontSize: 11, fontFamily: 'Cairo')),
            ],
          ),
        ],
      ),
    );
  }
}

class _AiAlert {
  final String text;
  final IconData icon;
  final Color color;
  _AiAlert(this.text, this.icon, this.color);
}

class _Stat {
  final String label, value, change;
  final IconData icon;
  final Color color;
  _Stat(this.label, this.value, this.change, this.icon, this.color);
}
