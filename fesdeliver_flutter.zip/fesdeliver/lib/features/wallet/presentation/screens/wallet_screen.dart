import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/providers/app_providers.dart';
import '../../../../core/models/models.dart';
import '../../../../core/services/payment_service.dart';

class WalletScreen extends ConsumerStatefulWidget {
  const WalletScreen({super.key});

  @override
  ConsumerState<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends ConsumerState<WalletScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final walletAsync = ref.watch(walletProvider);
    final txAsync = ref.watch(transactionsProvider);

    return Scaffold(
      backgroundColor: FesColors.bgDark,
      appBar: AppBar(
        backgroundColor: FesColors.cardDark,
        title: const Text('المحفظة الذكية', style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w700)),
        actions: [
          IconButton(
            icon: const Icon(Icons.info_outline_rounded),
            onPressed: () => _showInfo(context),
          ),
        ],
        bottom: TabBar(
          controller: _tabCtrl,
          indicatorColor: FesColors.green,
          labelStyle: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w700),
          unselectedLabelStyle: const TextStyle(fontFamily: 'Cairo'),
          tabs: const [Tab(text: 'نظرة عامة'), Tab(text: 'السجل')],
        ),
      ),
      body: TabBarView(
        controller: _tabCtrl,
        children: [
          // Overview tab
          SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                // Balance card
                walletAsync.when(
                  loading: () => const _BalanceCardSkeleton(),
                  error: (_, __) => const SizedBox(),
                  data: (wallet) => _BalanceCard(wallet: wallet),
                ),
                const SizedBox(height: 20),

                // Actions
                _ActionsRow(onTopUp: () => _showTopUpSheet(context)),
                const SizedBox(height: 24),

                // Loyalty points
                walletAsync.when(
                  loading: () => const SizedBox(),
                  error: (_, __) => const SizedBox(),
                  data: (wallet) => wallet != null ? _LoyaltyCard(points: wallet.loyaltyPoints) : const SizedBox(),
                ),
                const SizedBox(height: 16),

                // Recent transactions
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('آخر العمليات', style: TextStyle(color: FesColors.textDark, fontSize: 15, fontWeight: FontWeight.w700, fontFamily: 'Cairo')),
                    TextButton(
                      onPressed: () => _tabCtrl.animateTo(1),
                      child: const Text('عرض الكل', style: TextStyle(color: FesColors.green, fontFamily: 'Cairo')),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                txAsync.when(
                  loading: () => const Center(child: CircularProgressIndicator()),
                  error: (_, __) => const SizedBox(),
                  data: (txs) => Column(
                    children: txs.take(5).map((tx) => _TxTile(tx: tx)).toList(),
                  ),
                ),
              ],
            ),
          ),

          // History tab
          txAsync.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (_, __) => const Center(child: Text('خطأ في التحميل')),
            data: (txs) => txs.isEmpty
                ? const _EmptyTx()
                : ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: txs.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (_, i) => _TxTile(tx: txs[i]),
                  ),
          ),
        ],
      ),
    );
  }

  void _showTopUpSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: FesColors.cardDark,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (_) => _TopUpSheet(),
    );
  }

  void _showInfo(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: FesColors.cardDark,
        title: const Text('المحفظة الذكية', style: TextStyle(color: FesColors.textDark, fontFamily: 'Cairo')),
        content: const Text(
          'محفظتك الداخلية في FesDeliver.\n\n'
          '• يمكنك تعبئتها عبر Stripe\n'
          '• تحويل الرصيد لأصدقائك فوراً\n'
          '• استخدامها للدفع مقابل طلباتك\n'
          '• كسب نقاط ولاء مع كل طلب\n\n'
          'الرصيد آمن ومشفر بالكامل.',
          style: TextStyle(color: FesColors.textMutedDark, fontFamily: 'Cairo', height: 1.7),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('حسناً', style: TextStyle(color: FesColors.green, fontFamily: 'Cairo')),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Balance Card
// ─────────────────────────────────────────────
class _BalanceCard extends StatelessWidget {
  const _BalanceCard({required this.wallet});
  final WalletModel? wallet;

  @override
  Widget build(BuildContext context) {
    final balance = wallet?.balance ?? 0.0;
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [FesColors.green, FesColors.greenDark],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: FesColors.gold.withOpacity(0.3)),
        boxShadow: [
          BoxShadow(color: FesColors.green.withOpacity(0.3), blurRadius: 30, offset: const Offset(0, 12)),
        ],
      ),
      child: Stack(
        children: [
          // Decoration circles
          Positioned(top: -30, right: -30,
            child: Container(width: 120, height: 120,
              decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(0.05)))),
          Positioned(bottom: -20, left: -20,
            child: Container(width: 100, height: 100,
              decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(0.05)))),

          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('الرصيد الحالي', style: TextStyle(color: Colors.white70, fontSize: 13, fontFamily: 'Cairo')),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Text('FesDeliver Wallet', style: TextStyle(color: Colors.white, fontSize: 11, fontFamily: 'Cairo')),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              RichText(
                text: TextSpan(
                  style: const TextStyle(color: Colors.white, fontFamily: 'Cairo'),
                  children: [
                    TextSpan(
                      text: NumberFormat('#,##0.00').format(balance),
                      style: const TextStyle(fontSize: 42, fontWeight: FontWeight.w900, letterSpacing: -1),
                    ),
                    const TextSpan(text: ' د.م.', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w400, color: Colors.white70)),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  const Icon(Icons.auto_awesome_rounded, color: FesColors.gold, size: 14),
                  const SizedBox(width: 6),
                  Text(
                    '${wallet?.loyaltyPoints ?? 0} نقطة ولاء',
                    style: const TextStyle(color: FesColors.gold, fontSize: 13, fontFamily: 'Cairo'),
                  ),
                  const SizedBox(width: 16),
                  const Icon(Icons.swap_horiz_rounded, color: Colors.white70, size: 14),
                  const SizedBox(width: 6),
                  const Text('تحويل فوري', style: TextStyle(color: Colors.white70, fontSize: 13, fontFamily: 'Cairo')),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _BalanceCardSkeleton extends StatelessWidget {
  const _BalanceCardSkeleton();

  @override
  Widget build(BuildContext context) => Container(
    height: 160,
    decoration: BoxDecoration(
      color: FesColors.cardDark,
      borderRadius: BorderRadius.circular(24),
    ),
    child: const Center(child: CircularProgressIndicator(color: FesColors.green)),
  );
}

// ─────────────────────────────────────────────
//  Actions Row
// ─────────────────────────────────────────────
class _ActionsRow extends StatelessWidget {
  const _ActionsRow({required this.onTopUp});
  final VoidCallback onTopUp;

  static const _actions = [
    ('تعبئة', Icons.add_rounded, FesColors.success),
    ('تحويل', Icons.swap_horiz_rounded, FesColors.info),
    ('سحب', Icons.arrow_downward_rounded, FesColors.warning),
    ('Stripe', Icons.credit_card_rounded, FesColors.gold),
  ];

  @override
  Widget build(BuildContext context) {
    return Row(
      children: _actions.map((a) => Expanded(
        child: GestureDetector(
          onTap: a.$1 == 'تعبئة' ? onTopUp : null,
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 4),
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(
              color: a.$3.withOpacity(0.1),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: a.$3.withOpacity(0.25)),
            ),
            child: Column(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: a.$3.withOpacity(0.15),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(a.$2, color: a.$3, size: 20),
                ),
                const SizedBox(height: 6),
                Text(a.$1, style: TextStyle(color: a.$3, fontSize: 12, fontFamily: 'Cairo', fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        ),
      )).toList(),
    );
  }
}

// ─────────────────────────────────────────────
//  Loyalty Card
// ─────────────────────────────────────────────
class _LoyaltyCard extends StatelessWidget {
  const _LoyaltyCard({required this.points});
  final int points;

  @override
  Widget build(BuildContext context) {
    final progress = (points % 100) / 100.0;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: FesColors.cardDark,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: FesColors.gold.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.star_rounded, color: FesColors.gold, size: 20),
              const SizedBox(width: 8),
              const Expanded(
                child: Text('نقاط الولاء', style: TextStyle(color: FesColors.textDark, fontSize: 14, fontWeight: FontWeight.w700, fontFamily: 'Cairo')),
              ),
              Text('$points نقطة', style: const TextStyle(color: FesColors.gold, fontSize: 14, fontWeight: FontWeight.w800, fontFamily: 'Cairo')),
            ],
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: progress,
              backgroundColor: FesColors.cardLightDark,
              valueColor: const AlwaysStoppedAnimation(FesColors.gold),
              minHeight: 6,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '${100 - (points % 100)} نقطة للحصول على 10 د.م. مجاناً',
            style: const TextStyle(color: FesColors.textMutedDark, fontSize: 12, fontFamily: 'Cairo'),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Transaction Tile
// ─────────────────────────────────────────────
class _TxTile extends StatelessWidget {
  const _TxTile({required this.tx});
  final TransactionModel tx;

  (IconData, Color, String) get _typeInfo {
    switch (tx.type) {
      case 'credit':       return (Icons.arrow_downward_rounded, FesColors.success, 'تعبئة');
      case 'debit':        return (Icons.arrow_upward_rounded, FesColors.danger, 'دفع');
      case 'transfer_in':  return (Icons.swap_horiz_rounded, FesColors.info, 'تحويل مستلم');
      case 'transfer_out': return (Icons.swap_horiz_rounded, FesColors.warning, 'تحويل مرسل');
      case 'refund':       return (Icons.refresh_rounded, FesColors.success, 'استرداد');
      default:             return (Icons.circle_outlined, FesColors.textMutedDark, tx.type);
    }
  }

  bool get _isCredit => tx.type == 'credit' || tx.type == 'transfer_in' || tx.type == 'refund';

  @override
  Widget build(BuildContext context) {
    final info = _typeInfo;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: FesColors.cardDark,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: FesColors.cardLightDark),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: info.$2.withOpacity(0.12),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(info.$1, color: info.$2, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(tx.description, style: const TextStyle(color: FesColors.textDark, fontSize: 14, fontWeight: FontWeight.w600, fontFamily: 'Cairo')),
                Text(
                  DateFormat('dd/MM/yyyy • HH:mm').format(tx.createdAt),
                  style: const TextStyle(color: FesColors.textMutedDark, fontSize: 11, fontFamily: 'Cairo'),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '${_isCredit ? '+' : '-'}${NumberFormat('#,##0.00').format(tx.amount)} د.م.',
                style: TextStyle(
                  color: _isCredit ? FesColors.success : FesColors.danger,
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  fontFamily: 'Cairo',
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: FesColors.success.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Text('مكتمل', style: TextStyle(color: FesColors.success, fontSize: 10, fontFamily: 'Cairo')),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _EmptyTx extends StatelessWidget {
  const _EmptyTx();

  @override
  Widget build(BuildContext context) => Center(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Icon(Icons.receipt_long_rounded, color: FesColors.textMutedDark, size: 64),
        const SizedBox(height: 16),
        const Text('لا توجد عمليات بعد', style: TextStyle(color: FesColors.textMutedDark, fontFamily: 'Cairo', fontSize: 15)),
        const SizedBox(height: 8),
        const Text('ستظهر هنا عمليات المحفظة', style: TextStyle(color: FesColors.textMutedDark, fontFamily: 'Cairo', fontSize: 13)),
      ],
    ),
  );
}

// ─────────────────────────────────────────────
//  Top-Up Bottom Sheet
// ─────────────────────────────────────────────
class _TopUpSheet extends ConsumerStatefulWidget {
  @override
  ConsumerState<_TopUpSheet> createState() => _TopUpSheetState();
}

class _TopUpSheetState extends ConsumerState<_TopUpSheet> {
  final _ctrl = TextEditingController();
  bool _isLoading = false;
  double? _selectedAmount;

  static const _quickAmounts = [50.0, 100.0, 200.0, 500.0];

  Future<void> _topUp() async {
    final amount = double.tryParse(_ctrl.text) ?? _selectedAmount;
    if (amount == null || amount < 20) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('أدخل مبلغاً صحيحاً (20 د.م. على الأقل)')),
      );
      return;
    }
    setState(() => _isLoading = true);

    final user = ref.read(authStateProvider).value;
    if (user == null) return;

    final result = await ref.read(paymentServiceProvider).topUpWallet(
      userId: user.uid,
      amount: amount,
    );

    setState(() => _isLoading = false);

    if (!mounted) return;
    Navigator.pop(context);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(result.success ? 'تمت التعبئة بنجاح ✅' : 'فشلت التعبئة: ${result.error}'),
        backgroundColor: result.success ? FesColors.success : FesColors.danger,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(width: 40, height: 4,
              decoration: BoxDecoration(color: FesColors.cardLightDark, borderRadius: BorderRadius.circular(2))),
            const SizedBox(height: 20),
            const Text('تعبئة المحفظة', style: TextStyle(color: FesColors.textDark, fontSize: 18, fontWeight: FontWeight.w700, fontFamily: 'Cairo')),
            const SizedBox(height: 20),
            Row(
              children: _quickAmounts.map((a) => Expanded(
                child: GestureDetector(
                  onTap: () { setState(() { _selectedAmount = a; _ctrl.text = a.toStringAsFixed(0); }); },
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    decoration: BoxDecoration(
                      color: _selectedAmount == a ? FesColors.green.withOpacity(0.2) : FesColors.cardLightDark,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _selectedAmount == a ? FesColors.green : Colors.transparent),
                    ),
                    child: Text('${a.toStringAsFixed(0)}\nد.م.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: _selectedAmount == a ? FesColors.textDark : FesColors.textMutedDark, fontSize: 13, fontFamily: 'Cairo', height: 1.4),
                    ),
                  ),
                ),
              )).toList(),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _ctrl,
              keyboardType: TextInputType.number,
              textAlign: TextAlign.center,
              style: const TextStyle(color: FesColors.textDark, fontSize: 18, fontFamily: 'Cairo', fontWeight: FontWeight.w700),
              decoration: const InputDecoration(hintText: 'أو أدخل مبلغاً آخر', suffixText: 'د.م.'),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _topUp,
                child: _isLoading
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : const Text('دفع عبر Stripe 💳', style: TextStyle(fontFamily: 'Cairo', fontSize: 16)),
              ),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}
