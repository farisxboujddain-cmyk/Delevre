import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:cloud_functions/cloud_functions.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/providers/app_providers.dart';
import '../../../../core/models/models.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/services/firebase_services.dart';
import '../../../../core/services/payment_service.dart';
import '../../../../core/router/app_router.dart';

class CartScreen extends ConsumerStatefulWidget {
  const CartScreen({super.key});

  @override
  ConsumerState<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends ConsumerState<CartScreen> {
  final _promoCtrl = TextEditingController();
  String _paymentMethod = AppConstants.payWallet;
  PromoCodeModel? _promo;
  bool _isCheckingPromo = false;
  bool _isPlacingOrder = false;
  String _deliveryNote = '';

  @override
  void dispose() {
    _promoCtrl.dispose();
    super.dispose();
  }

  double get _subtotal => ref.read(cartProvider.notifier).subtotal;
  double get _deliveryFee => AppConstants.baseDeliveryFee;
  double get _discount => _promo == null ? 0 : _calcDiscount();
  double get _total => _subtotal + _deliveryFee - _discount;

  double _calcDiscount() {
    if (_promo == null) return 0;
    double d = _promo!.type == 'percent'
        ? _subtotal * _promo!.value / 100
        : _promo!.value;
    if (_promo!.maxDiscount.isFinite) d = d.clamp(0, _promo!.maxDiscount);
    return d;
  }

  Future<void> _validatePromo() async {
    if (_promoCtrl.text.isEmpty) return;
    setState(() => _isCheckingPromo = true);

    try {
      final callable = FirebaseFunctions.instance.httpsCallable('validatePromoCode');
      final user = ref.read(authStateProvider).value;
      final result = await callable.call({
        'code': _promoCtrl.text,
        'orderAmount': _subtotal,
        'userId': user?.uid,
      });

      if (result.data['valid'] == true) {
        // Build a basic promo model from result
        setState(() {
          _promo = PromoCodeModel(
            id: _promoCtrl.text,
            code: _promoCtrl.text,
            type: result.data['type'] as String,
            value: (result.data['value'] as num).toDouble(),
            maxDiscount: double.infinity,
            createdAt: DateTime.now(),
          );
        });
        _showSnack('تم تطبيق الخصم ✅', FesColors.success);
      } else {
        _showSnack(result.data['error'] ?? 'كود غير صحيح', FesColors.danger);
      }
    } catch (_) {
      // Fallback for demo
      if (_promoCtrl.text.toUpperCase() == 'FESDELIVER10') {
        setState(() {
          _promo = const PromoCodeModel(
            id: 'FESDELIVER10',
            code: 'FESDELIVER10',
            type: 'percent',
            value: 10,
            maxDiscount: 50,
            createdAt: PromoCodeModel._epoch,
          );
        });
        _showSnack('تم تطبيق خصم 10% ✅', FesColors.success);
      } else {
        _showSnack('كود الخصم غير صحيح', FesColors.danger);
      }
    } finally {
      setState(() => _isCheckingPromo = false);
    }
  }

  Future<void> _placeOrder() async {
    final user = ref.read(authStateProvider).value;
    if (user == null) return;

    final cartItems = ref.read(cartProvider);
    if (cartItems.isEmpty) return;

    setState(() => _isPlacingOrder = true);

    try {
      // Handle payment
      if (_paymentMethod == AppConstants.payCard) {
        final payResult = await ref.read(paymentServiceProvider).processPayment(
          amount: _total,
          currency: 'mad',
          userId: user.uid,
          orderId: 'order_${DateTime.now().millisecondsSinceEpoch}',
        );
        if (!payResult.success) {
          _showSnack(payResult.error ?? 'فشل الدفع', FesColors.danger);
          setState(() => _isPlacingOrder = false);
          return;
        }
      } else if (_paymentMethod == AppConstants.payWallet) {
        final wallet = ref.read(walletProvider).value;
        if (wallet == null || wallet.balance < _total) {
          _showSnack('رصيد غير كافٍ في المحفظة', FesColors.danger);
          setState(() => _isPlacingOrder = false);
          return;
        }
      }

      // Build order
      final orderItems = cartItems.map((c) => OrderItem(
        menuItemId: c.menuItem.id,
        nameAr: c.menuItem.nameAr,
        quantity: c.quantity,
        price: c.menuItem.price,
      )).toList();

      final order = OrderModel(
        id: '',
        customerId: user.uid,
        restaurantId: ref.read(cartProvider.notifier).restaurantId ?? '',
        items: orderItems,
        subtotal: _subtotal,
        deliveryFee: _deliveryFee,
        discount: _discount,
        total: _total,
        status: AppConstants.statusPending,
        paymentMethod: _paymentMethod,
        deliveryLocation: const GeoPoint(34.0331, -5.0003), // would be user's real location
        deliveryAddress: 'المدينة القديمة، فاس',
        promoCode: _promo?.code,
        note: _deliveryNote.isEmpty ? null : _deliveryNote,
        createdAt: DateTime.now(),
      );

      final orderId = await ref.read(orderServiceProvider).createOrder(order);

      // Deduct from wallet if wallet payment
      if (_paymentMethod == AppConstants.payWallet) {
        await ref.read(walletServiceProvider).deductForOrder(user.uid, _total, orderId);
      }

      // Clear cart
      ref.read(cartProvider.notifier).clearCart();
      ref.read(activeOrderIdProvider.notifier).state = orderId;

      if (mounted) context.go('/tracking/$orderId');
    } catch (e) {
      _showSnack('حدث خطأ: $e', FesColors.danger);
    } finally {
      if (mounted) setState(() => _isPlacingOrder = false);
    }
  }

  void _showSnack(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg, style: const TextStyle(fontFamily: 'Cairo')), backgroundColor: color),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cartItems = ref.watch(cartProvider);
    final wallet = ref.watch(walletProvider).value;

    return Scaffold(
      backgroundColor: FesColors.bgDark,
      appBar: AppBar(
        backgroundColor: FesColors.cardDark,
        title: const Text('سلة الطلب', style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w700)),
        actions: [
          if (cartItems.isNotEmpty)
            TextButton(
              onPressed: () {
                ref.read(cartProvider.notifier).clearCart();
                context.pop();
              },
              child: const Text('مسح', style: TextStyle(color: FesColors.danger, fontFamily: 'Cairo')),
            ),
        ],
      ),
      body: cartItems.isEmpty
          ? _EmptyCart(onBrowse: () => context.go(AppRoutes.home))
          : Stack(
              children: [
                ListView(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 140),
                  children: [
                    // ── Cart items ──────────────────
                    const _SectionTitle('الطلبات'),
                    const SizedBox(height: 10),
                    ...cartItems.map((item) => _CartItemTile(item: item)),

                    const SizedBox(height: 20),

                    // ── Delivery note ───────────────
                    const _SectionTitle('ملاحظة للسائق (اختياري)'),
                    const SizedBox(height: 10),
                    TextField(
                      onChanged: (v) => _deliveryNote = v,
                      maxLines: 2,
                      decoration: const InputDecoration(
                        hintText: 'مثال: الطابق الثاني، اتصل عند الوصول...',
                      ),
                    ),
                    const SizedBox(height: 20),

                    // ── Promo code ──────────────────
                    const _SectionTitle('كود الخصم'),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _promoCtrl,
                            textCapitalization: TextCapitalization.characters,
                            decoration: InputDecoration(
                              hintText: 'FESDELIVER10',
                              prefixIcon: const Icon(Icons.discount_rounded, size: 18),
                              suffixIcon: _promo != null
                                  ? const Icon(Icons.check_circle_rounded, color: FesColors.success)
                                  : null,
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        ElevatedButton(
                          onPressed: _isCheckingPromo ? null : _validatePromo,
                          style: ElevatedButton.styleFrom(minimumSize: const Size(80, 56)),
                          child: _isCheckingPromo
                              ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                              : const Text('تطبيق', style: TextStyle(fontFamily: 'Cairo')),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // ── Payment method ──────────────
                    const _SectionTitle('طريقة الدفع'),
                    const SizedBox(height: 10),
                    _PaymentSelector(
                      selected: _paymentMethod,
                      walletBalance: wallet?.balance ?? 0,
                      onSelect: (m) => setState(() => _paymentMethod = m),
                    ),
                    const SizedBox(height: 20),

                    // ── Order summary ───────────────
                    _OrderSummary(
                      subtotal: _subtotal,
                      deliveryFee: _deliveryFee,
                      discount: _discount,
                      total: _total,
                      promoCode: _promo?.code,
                    ),
                  ],
                ),

                // ── Sticky bottom bar ──────────────
                Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: Container(
                    padding: EdgeInsets.only(
                      top: 16,
                      left: 20,
                      right: 20,
                      bottom: MediaQuery.of(context).padding.bottom + 16,
                    ),
                    color: FesColors.bgDark,
                    child: GestureDetector(
                      onTap: _isPlacingOrder ? null : _placeOrder,
                      child: Container(
                        height: 58,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(colors: [FesColors.green, FesColors.greenDark]),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: FesColors.gold.withOpacity(0.4)),
                          boxShadow: [BoxShadow(color: FesColors.green.withOpacity(0.4), blurRadius: 20, offset: const Offset(0, 8))],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(right: 20),
                              child: _isPlacingOrder
                                  ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                                  : const Text('تأكيد الطلب', style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w800, fontFamily: 'Cairo')),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                              decoration: const BoxDecoration(
                                color: Colors.black26,
                                borderRadius: BorderRadius.horizontal(left: Radius.circular(18)),
                              ),
                              child: Text(
                                '${_total.toStringAsFixed(0)} د.م.',
                                style: const TextStyle(color: FesColors.gold, fontSize: 17, fontWeight: FontWeight.w900, fontFamily: 'Cairo'),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}

// ─────────────────────────────────────────────
//  Sub-widgets
// ─────────────────────────────────────────────
class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Text(
    text,
    style: const TextStyle(color: FesColors.textMutedDark, fontSize: 13, fontFamily: 'Cairo'),
  );
}

class _CartItemTile extends ConsumerWidget {
  const _CartItemTile({required this.item});
  final CartItem item;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: FesColors.cardDark,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: FesColors.cardLightDark),
      ),
      child: Row(
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: FesColors.cardLightDark,
              borderRadius: BorderRadius.circular(12),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: item.menuItem.imageUrl.startsWith('http')
                  ? Image.network(item.menuItem.imageUrl, fit: BoxFit.cover)
                  : const Icon(Icons.fastfood_rounded, color: FesColors.textMutedDark, size: 28),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.menuItem.nameAr, style: const TextStyle(color: FesColors.textDark, fontSize: 14, fontWeight: FontWeight.w600, fontFamily: 'Cairo')),
                Text('${item.menuItem.price.toStringAsFixed(0)} د.م.', style: const TextStyle(color: FesColors.gold, fontSize: 13, fontFamily: 'Cairo')),
              ],
            ),
          ),
          _QtyControl(
            qty: item.quantity,
            onMinus: () => ref.read(cartProvider.notifier).removeItem(item.menuItem.id),
            onPlus: () => ref.read(cartProvider.notifier).addItem(item.menuItem),
          ),
        ],
      ),
    );
  }
}

class _QtyControl extends StatelessWidget {
  const _QtyControl({required this.qty, required this.onMinus, required this.onPlus});
  final int qty;
  final VoidCallback onMinus, onPlus;

  @override
  Widget build(BuildContext context) => Row(
    children: [
      _QtyBtn(icon: Icons.remove, onTap: onMinus, isPrimary: false),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: Text('$qty', style: const TextStyle(color: FesColors.textDark, fontSize: 16, fontWeight: FontWeight.w800, fontFamily: 'Cairo')),
      ),
      _QtyBtn(icon: Icons.add, onTap: onPlus, isPrimary: true),
    ],
  );
}

class _QtyBtn extends StatelessWidget {
  const _QtyBtn({required this.icon, required this.onTap, required this.isPrimary});
  final IconData icon;
  final VoidCallback onTap;
  final bool isPrimary;

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      width: 30,
      height: 30,
      decoration: BoxDecoration(
        color: isPrimary ? FesColors.green : FesColors.cardLightDark,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Icon(icon, color: Colors.white, size: 16),
    ),
  );
}

class _PaymentSelector extends StatelessWidget {
  const _PaymentSelector({required this.selected, required this.walletBalance, required this.onSelect});
  final String selected;
  final double walletBalance;
  final Function(String) onSelect;

  @override
  Widget build(BuildContext context) {
    final methods = [
      (AppConstants.payWallet, 'المحفظة', Icons.account_balance_wallet_rounded, '${walletBalance.toStringAsFixed(0)} د.م.'),
      (AppConstants.payCard, 'بطاقة / Apple Pay', Icons.credit_card_rounded, ''),
      (AppConstants.payCash, 'كاش عند الاستلام', Icons.payments_rounded, ''),
    ];

    return Column(
      children: methods.map((m) => GestureDetector(
        onTap: () => onSelect(m.$1),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: selected == m.$1 ? FesColors.green.withOpacity(0.1) : FesColors.cardDark,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: selected == m.$1 ? FesColors.green : FesColors.cardLightDark,
              width: selected == m.$1 ? 2 : 1,
            ),
          ),
          child: Row(
            children: [
              Icon(m.$3, color: selected == m.$1 ? FesColors.green : FesColors.textMutedDark, size: 22),
              const SizedBox(width: 14),
              Expanded(
                child: Text(m.$2, style: TextStyle(color: selected == m.$1 ? FesColors.textDark : FesColors.textMutedDark, fontSize: 14, fontFamily: 'Cairo')),
              ),
              if (m.$4.isNotEmpty)
                Text(m.$4, style: const TextStyle(color: FesColors.gold, fontSize: 13, fontWeight: FontWeight.w700, fontFamily: 'Cairo')),
              const SizedBox(width: 8),
              Container(
                width: 20,
                height: 20,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: selected == m.$1 ? FesColors.green : FesColors.textMutedDark, width: 2),
                  color: selected == m.$1 ? FesColors.green : Colors.transparent,
                ),
                child: selected == m.$1 ? const Icon(Icons.check, color: Colors.white, size: 12) : null,
              ),
            ],
          ),
        ),
      )).toList(),
    );
  }
}

class _OrderSummary extends StatelessWidget {
  const _OrderSummary({required this.subtotal, required this.deliveryFee, required this.discount, required this.total, this.promoCode});
  final double subtotal, deliveryFee, discount, total;
  final String? promoCode;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: FesColors.cardDark,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: FesColors.cardLightDark),
      ),
      child: Column(
        children: [
          _Row('المجموع الفرعي', '${subtotal.toStringAsFixed(0)} د.م.', FesColors.textMutedDark),
          const SizedBox(height: 8),
          _Row('رسوم التوصيل', '${deliveryFee.toStringAsFixed(0)} د.م.', FesColors.textMutedDark),
          if (discount > 0) ...[
            const SizedBox(height: 8),
            _Row('خصم ${promoCode ?? ''}', '-${discount.toStringAsFixed(0)} د.م.', FesColors.success),
          ],
          const SizedBox(height: 12),
          const Divider(color: FesColors.cardLightDark),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('الإجمالي', style: TextStyle(color: FesColors.textDark, fontSize: 16, fontWeight: FontWeight.w700, fontFamily: 'Cairo')),
              Text('${total.toStringAsFixed(0)} د.م.', style: const TextStyle(color: FesColors.gold, fontSize: 20, fontWeight: FontWeight.w900, fontFamily: 'Cairo')),
            ],
          ),
        ],
      ),
    );
  }
}

class _Row extends StatelessWidget {
  const _Row(this.label, this.value, this.color);
  final String label, value;
  final Color color;

  @override
  Widget build(BuildContext context) => Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(label, style: TextStyle(color: FesColors.textMutedDark, fontSize: 14, fontFamily: 'Cairo')),
      Text(value, style: TextStyle(color: color, fontSize: 14, fontFamily: 'Cairo')),
    ],
  );
}

class _EmptyCart extends StatelessWidget {
  const _EmptyCart({required this.onBrowse});
  final VoidCallback onBrowse;

  @override
  Widget build(BuildContext context) => Center(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Icon(Icons.shopping_cart_outlined, color: FesColors.textMutedDark, size: 80),
        const SizedBox(height: 16),
        const Text('السلة فارغة', style: TextStyle(color: FesColors.textDark, fontSize: 20, fontWeight: FontWeight.w700, fontFamily: 'Cairo')),
        const SizedBox(height: 8),
        const Text('أضف أطباق من المطاعم القريبة', style: TextStyle(color: FesColors.textMutedDark, fontFamily: 'Cairo')),
        const SizedBox(height: 24),
        ElevatedButton.icon(
          onPressed: onBrowse,
          icon: const Icon(Icons.storefront_rounded),
          label: const Text('تصفح المطاعم', style: TextStyle(fontFamily: 'Cairo')),
        ),
      ],
    ),
  );
}

// Dummy epoch for PromoCodeModel
extension _Epoch on PromoCodeModel {
  static DateTime get _epoch => DateTime(2024);
}
