import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/providers/app_providers.dart';
import '../../../../core/router/app_router.dart';

class SplashScreen extends ConsumerStatefulWidget {
  const SplashScreen({super.key});

  @override
  ConsumerState<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends ConsumerState<SplashScreen>
    with TickerProviderStateMixin {
  late AnimationController _logoCtrl;
  late AnimationController _progressCtrl;
  late Animation<double> _scaleAnim;
  late Animation<double> _fadeAnim;
  late Animation<double> _progressAnim;

  @override
  void initState() {
    super.initState();

    _logoCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _progressCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 2000));

    _scaleAnim  = CurvedAnimation(parent: _logoCtrl, curve: Curves.elasticOut);
    _fadeAnim   = CurvedAnimation(parent: _logoCtrl, curve: Curves.easeOut);
    _progressAnim = CurvedAnimation(parent: _progressCtrl, curve: Curves.easeInOut);

    _logoCtrl.forward();

    Future.delayed(const Duration(milliseconds: 300), () {
      _progressCtrl.forward();
    });

    Future.delayed(const Duration(milliseconds: 2500), _navigate);
  }

  void _navigate() {
    final authState = ref.read(authStateProvider);
    authState.whenData((user) {
      if (!mounted) return;
      if (user != null) {
        context.go(AppRoutes.home);
      } else {
        context.go(AppRoutes.login);
      }
    });
  }

  @override
  void dispose() {
    _logoCtrl.dispose();
    _progressCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: FesColors.bgDark,
      body: Stack(
        children: [
          // Background radial glows
          Positioned(
            top: -100,
            left: -50,
            child: Container(
              width: 350,
              height: 350,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [FesColors.green.withOpacity(0.15), Colors.transparent],
                ),
              ),
            ),
          ),
          Positioned(
            bottom: -80,
            right: -80,
            child: Container(
              width: 280,
              height: 280,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [FesColors.gold.withOpacity(0.1), Colors.transparent],
                ),
              ),
            ),
          ),

          // Geometric pattern
          ...List.generate(5, (i) => Positioned(
            top: 80.0 + i * 120,
            right: -20,
            child: Opacity(
              opacity: 0.04,
              child: Container(
                width: 60 + i * 20.0,
                height: 60 + i * 20.0,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: FesColors.green, width: 1),
                ),
              ),
            ),
          )),

          // Main content
          Center(
            child: FadeTransition(
              opacity: _fadeAnim,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Logo
                  ScaleTransition(
                    scale: _scaleAnim,
                    child: Container(
                      width: 100,
                      height: 100,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [FesColors.green, FesColors.greenDark],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(28),
                        border: Border.all(color: FesColors.gold.withOpacity(0.5), width: 2),
                        boxShadow: [
                          BoxShadow(
                            color: FesColors.green.withOpacity(0.5),
                            blurRadius: 40,
                            offset: const Offset(0, 16),
                          ),
                        ],
                      ),
                      child: const Icon(Icons.two_wheeler_rounded, color: Colors.white, size: 52),
                    ),
                  ),
                  const SizedBox(height: 24),

                  // App name
                  RichText(
                    text: const TextSpan(
                      style: TextStyle(fontSize: 40, fontWeight: FontWeight.w900, fontFamily: 'Cairo', letterSpacing: -1),
                      children: [
                        TextSpan(text: 'Fes', style: TextStyle(color: FesColors.textDark)),
                        TextSpan(text: 'Deliver', style: TextStyle(color: FesColors.gold)),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),

                  // Tagline
                  const Text(
                    'توصيل ذكي • Livraison Intelligente',
                    style: TextStyle(
                      color: FesColors.textMutedDark,
                      fontSize: 13,
                      letterSpacing: 1.5,
                      fontFamily: 'Cairo',
                    ),
                  ),
                  const SizedBox(height: 12),

                  // AI badge
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                    decoration: BoxDecoration(
                      color: FesColors.gold.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: FesColors.gold.withOpacity(0.3)),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text('✨', style: TextStyle(fontSize: 14)),
                        SizedBox(width: 6),
                        Text(
                          'مدعوم بالذكاء الاصطناعي',
                          style: TextStyle(color: FesColors.gold, fontSize: 12, fontFamily: 'Cairo'),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 60),

                  // Progress bar
                  SizedBox(
                    width: 180,
                    child: AnimatedBuilder(
                      animation: _progressAnim,
                      builder: (_, __) => Column(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(4),
                            child: LinearProgressIndicator(
                              value: _progressAnim.value,
                              backgroundColor: FesColors.cardLightDark,
                              valueColor: const AlwaysStoppedAnimation(FesColors.green),
                              minHeight: 3,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Version
          Positioned(
            bottom: 40,
            left: 0,
            right: 0,
            child: FadeTransition(
              opacity: _fadeAnim,
              child: const Text(
                'v1.0.0 • فاس، المغرب 🇲🇦',
                textAlign: TextAlign.center,
                style: TextStyle(color: FesColors.textMutedDark, fontSize: 11, fontFamily: 'Cairo'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
