import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/services/firebase_services.dart';
import '../../../../core/router/app_router.dart';

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});

  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _animCtrl;
  late Animation<double> _fadeAnim;

  final _phoneCtrl = TextEditingController();
  bool _isLoading = false;
  bool _showOtp = false;
  String _verificationId = '';
  String _selectedRole = 'customer';

  static const _roles = [
    ('customer', 'زبون',  '👤'),
    ('merchant', 'تاجر',  '🏪'),
    ('driver',   'سائق',  '🛵'),
    ('admin',    'إدارة', '⚙️'),
  ];

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fadeAnim = CurvedAnimation(parent: _animCtrl, curve: Curves.easeOut);
    _animCtrl.forward();
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    _phoneCtrl.dispose();
    super.dispose();
  }

  Future<void> _sendOtp() async {
    if (_phoneCtrl.text.length < 10) {
      _showSnack('أدخل رقم هاتف صحيح');
      return;
    }
    setState(() => _isLoading = true);

    await ref.read(authServiceProvider).sendOtp(
      phone: _phoneCtrl.text,
      onCodeSent: (id) {
        setState(() { _verificationId = id; _showOtp = true; _isLoading = false; });
      },
      onError: (e) {
        setState(() => _isLoading = false);
        _showSnack(e);
      },
    );
  }

  Future<void> _verifyOtp(String code) async {
    setState(() => _isLoading = true);
    try {
      final cred = await ref.read(authServiceProvider).verifyOtp(
        verificationId: _verificationId,
        smsCode: code,
      );
      if (cred.user != null) {
        await ref.read(authServiceProvider).createUserDocument(
          uid: cred.user!.uid,
          name: cred.user!.displayName ?? 'مستخدم جديد',
          phone: _phoneCtrl.text,
          role: _selectedRole,
          email: cred.user!.email,
        );
        if (mounted) context.go(AppRoutes.home);
      }
    } catch (e) {
      _showSnack('رمز خاطئ، حاول مجدداً');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _googleSignIn() async {
    setState(() => _isLoading = true);
    try {
      final cred = await ref.read(authServiceProvider).signInWithGoogle();
      if (cred?.user != null) {
        await ref.read(authServiceProvider).createUserDocument(
          uid: cred!.user!.uid,
          name: cred.user!.displayName ?? 'مستخدم',
          phone: cred.user!.phoneNumber ?? '',
          role: _selectedRole,
          email: cred.user!.email,
          photoUrl: cred.user!.photoURL,
        );
        if (mounted) context.go(AppRoutes.home);
      }
    } catch (e) {
      _showSnack('فشل تسجيل الدخول بـ Google');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg, style: const TextStyle(fontFamily: 'Cairo'))),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: FesColors.bgDark,
      body: Stack(
        children: [
          // Background decoration
          Positioned(
            top: -100,
            right: -80,
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: FesColors.green.withOpacity(0.08),
              ),
            ),
          ),
          Positioned(
            bottom: -60,
            left: -60,
            child: Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: FesColors.gold.withOpacity(0.06),
              ),
            ),
          ),

          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnim,
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    const SizedBox(height: 40),

                    // ── Logo ────────────────────────────
                    Container(
                      width: 90,
                      height: 90,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [FesColors.green, FesColors.greenDark],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: FesColors.gold.withOpacity(0.4), width: 2),
                        boxShadow: [
                          BoxShadow(color: FesColors.green.withOpacity(0.4), blurRadius: 30, offset: const Offset(0, 10)),
                        ],
                      ),
                      child: const Icon(Icons.two_wheeler_rounded, color: Colors.white, size: 44),
                    ),
                    const SizedBox(height: 16),

                    RichText(
                      text: const TextSpan(
                        style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, fontFamily: 'Cairo'),
                        children: [
                          TextSpan(text: 'Fes', style: TextStyle(color: FesColors.textDark)),
                          TextSpan(text: 'Deliver', style: TextStyle(color: FesColors.gold)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      'توصيل ذكي • Livraison Intelligente',
                      style: TextStyle(color: FesColors.textMutedDark, fontSize: 13, letterSpacing: 1, fontFamily: 'Cairo'),
                    ),

                    const SizedBox(height: 40),

                    if (!_showOtp) ...[
                      // ── Role selector ──────────────────
                      _SectionLabel('اختر نوع حسابك'),
                      const SizedBox(height: 10),
                      GridView.count(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        crossAxisCount: 4,
                        crossAxisSpacing: 10,
                        mainAxisSpacing: 10,
                        children: _roles.map((r) => _RoleCard(
                          role: r.$1,
                          label: r.$2,
                          emoji: r.$3,
                          isSelected: _selectedRole == r.$1,
                          onTap: () => setState(() => _selectedRole = r.$1),
                        )).toList(),
                      ),
                      const SizedBox(height: 24),

                      // ── Phone input ────────────────────
                      _SectionLabel('رقم الهاتف'),
                      const SizedBox(height: 10),
                      TextField(
                        controller: _phoneCtrl,
                        keyboardType: TextInputType.phone,
                        textDirection: TextDirection.ltr,
                        style: const TextStyle(color: FesColors.textDark, fontSize: 16, fontFamily: 'Cairo'),
                        decoration: const InputDecoration(
                          hintText: '+212 6XX XXX XXX',
                          prefixIcon: Icon(Icons.phone_rounded, color: FesColors.textMutedDark),
                        ),
                      ),
                      const SizedBox(height: 16),

                      // ── Send OTP ───────────────────────
                      _PrimaryButton(
                        label: 'إرسال رمز التحقق',
                        icon: Icons.sms_rounded,
                        isLoading: _isLoading,
                        onTap: _sendOtp,
                      ),
                      const SizedBox(height: 20),

                      // ── Divider ────────────────────────
                      Row(
                        children: [
                          const Expanded(child: Divider(color: FesColors.cardLightDark)),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            child: Text('أو', style: TextStyle(color: FesColors.textMutedDark, fontFamily: 'Cairo')),
                          ),
                          const Expanded(child: Divider(color: FesColors.cardLightDark)),
                        ],
                      ),
                      const SizedBox(height: 20),

                      // ── Google ─────────────────────────
                      _GoogleButton(isLoading: _isLoading, onTap: _googleSignIn),
                    ] else ...[
                      // ── OTP Screen ─────────────────────
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: FesColors.green.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: FesColors.green.withOpacity(0.3)),
                        ),
                        child: Column(
                          children: [
                            const Icon(Icons.sms_rounded, color: FesColors.green, size: 36),
                            const SizedBox(height: 12),
                            Text(
                              'أدخل الرمز المرسل إلى\n${_phoneCtrl.text}',
                              textAlign: TextAlign.center,
                              style: const TextStyle(color: FesColors.textDark, fontSize: 14, fontFamily: 'Cairo', height: 1.6),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 32),

                      PinCodeTextField(
                        appContext: context,
                        length: 6,
                        textStyle: const TextStyle(color: FesColors.textDark, fontSize: 22, fontWeight: FontWeight.w800, fontFamily: 'Cairo'),
                        pinTheme: PinTheme(
                          shape: PinCodeFieldShape.box,
                          borderRadius: BorderRadius.circular(14),
                          fieldHeight: 58,
                          fieldWidth: 48,
                          activeColor: FesColors.green,
                          inactiveColor: FesColors.cardLightDark,
                          selectedColor: FesColors.gold,
                          activeFillColor: FesColors.cardDark,
                          inactiveFillColor: FesColors.cardDark,
                          selectedFillColor: FesColors.cardDark,
                        ),
                        enableActiveFill: true,
                        onCompleted: _verifyOtp,
                        onChanged: (_) {},
                      ),
                      const SizedBox(height: 24),

                      if (_isLoading)
                        const CircularProgressIndicator(color: FesColors.green)
                      else ...[
                        TextButton(
                          onPressed: () => setState(() => _showOtp = false),
                          child: const Text('تغيير رقم الهاتف', style: TextStyle(color: FesColors.textMutedDark, fontFamily: 'Cairo')),
                        ),
                        TextButton(
                          onPressed: _sendOtp,
                          child: const Text('إعادة إرسال الرمز', style: TextStyle(color: FesColors.green, fontFamily: 'Cairo')),
                        ),
                      ],
                    ],

                    const SizedBox(height: 24),
                    Text(
                      'بالمتابعة، أنت توافق على شروط الخدمة\nوسياسة الخصوصية الخاصة بـ FesDeliver',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: FesColors.textMutedDark, fontSize: 11, height: 1.6, fontFamily: 'Cairo'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Sub-widgets
// ─────────────────────────────────────────────
class _SectionLabel extends StatelessWidget {
  const _SectionLabel(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Align(
    alignment: Alignment.centerRight,
    child: Text(
      text,
      style: const TextStyle(color: FesColors.textMutedDark, fontSize: 13, fontFamily: 'Cairo'),
    ),
  );
}

class _RoleCard extends StatelessWidget {
  const _RoleCard({
    required this.role, required this.label, required this.emoji,
    required this.isSelected, required this.onTap,
  });
  final String role, label, emoji;
  final bool isSelected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      decoration: BoxDecoration(
        color: isSelected ? FesColors.green.withOpacity(0.2) : FesColors.cardDark,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isSelected ? FesColors.green : FesColors.cardLightDark,
          width: isSelected ? 2 : 1,
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 22)),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              color: isSelected ? FesColors.textDark : FesColors.textMutedDark,
              fontSize: 11,
              fontWeight: isSelected ? FontWeight.w700 : FontWeight.w400,
              fontFamily: 'Cairo',
            ),
          ),
        ],
      ),
    ),
  );
}

class _PrimaryButton extends StatelessWidget {
  const _PrimaryButton({required this.label, required this.icon, required this.isLoading, required this.onTap});
  final String label;
  final IconData icon;
  final bool isLoading;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: isLoading ? null : onTap,
    child: Container(
      height: 56,
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [FesColors.green, FesColors.greenDark]),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: FesColors.gold.withOpacity(0.3)),
        boxShadow: [BoxShadow(color: FesColors.green.withOpacity(0.4), blurRadius: 20, offset: const Offset(0, 8))],
      ),
      child: Center(
        child: isLoading
            ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
            : Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(icon, color: Colors.white, size: 20),
                  const SizedBox(width: 10),
                  Text(label, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700, fontFamily: 'Cairo')),
                ],
              ),
      ),
    ),
  );
}

class _GoogleButton extends StatelessWidget {
  const _GoogleButton({required this.isLoading, required this.onTap});
  final bool isLoading;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: isLoading ? null : onTap,
    child: Container(
      height: 56,
      decoration: BoxDecoration(
        color: FesColors.cardDark,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: FesColors.cardLightDark),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text('🔵', style: TextStyle(fontSize: 22)),
          const SizedBox(width: 12),
          const Text('الدخول بـ Google', style: TextStyle(color: FesColors.textDark, fontSize: 15, fontWeight: FontWeight.w600, fontFamily: 'Cairo')),
        ],
      ),
    ),
  );
}
