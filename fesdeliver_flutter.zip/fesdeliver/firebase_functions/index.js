const functions = require("firebase-functions");
const admin = require("firebase-admin");
const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);
const { GoogleGenerativeAI } = require("@google/generative-ai");

admin.initializeApp();
const db = admin.firestore();
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// ─────────────────────────────────────────────
//  STRIPE: Create Payment Intent
// ─────────────────────────────────────────────
exports.createPaymentIntent = functions.https.onCall(async (data, context) => {
  if (!context.auth) throw new functions.https.HttpsError("unauthenticated", "يجب تسجيل الدخول");

  const { amount, currency, userId, orderId, description } = data;

  if (!amount || amount < 100) {
    throw new functions.https.HttpsError("invalid-argument", "مبلغ غير صحيح");
  }

  const paymentIntent = await stripe.paymentIntents.create({
    amount,
    currency: currency || "mad",
    description,
    metadata: { userId, orderId, platform: "fesdeliver" },
    automatic_payment_methods: { enabled: true },
  });

  return { clientSecret: paymentIntent.client_secret };
});

// ─────────────────────────────────────────────
//  STRIPE: Refund
// ─────────────────────────────────────────────
exports.refundPayment = functions.https.onCall(async (data, context) => {
  if (!context.auth) throw new functions.https.HttpsError("unauthenticated", "يجب تسجيل الدخول");

  const refund = await stripe.refunds.create({
    payment_intent: data.paymentIntentId,
    amount: data.amount,
  });

  return { success: refund.status === "succeeded" };
});

// ─────────────────────────────────────────────
//  ORDER TRIGGERS: Notify on status change
// ─────────────────────────────────────────────
exports.onOrderStatusChange = functions.firestore
  .document("orders/{orderId}")
  .onUpdate(async (change, context) => {
    const before = change.before.data();
    const after = change.after.data();

    if (before.status === after.status) return;

    const statusMessages = {
      accepted:   { title: "✅ تم قبول طلبك!", body: "المطعم بدأ التحضير" },
      preparing:  { title: "👨‍🍳 طلبك قيد التحضير", body: "جاري تحضير طلبك بعناية" },
      picked:     { title: "🛵 السائق في الطريق!", body: "طلبك قادم إليك" },
      delivered:  { title: "🎉 تم توصيل طلبك!", body: "استمتع بطعامك. قيّم تجربتك!" },
      cancelled:  { title: "❌ تم إلغاء طلبك", body: after.cancellationReason || "تم الإلغاء" },
    };

    const msg = statusMessages[after.status];
    if (!msg) return;

    // Get customer FCM token
    const customerDoc = await db.collection("users").doc(after.customerId).get();
    const fcmToken = customerDoc.data()?.fcmToken;

    if (!fcmToken) return;

    await admin.messaging().send({
      token: fcmToken,
      notification: { title: msg.title, body: msg.body },
      data: { orderId: context.params.orderId, status: after.status, type: "order_update" },
      android: {
        notification: {
          channelId: "fesdeliver_main",
          priority: "high",
          color: "#1B6B3A",
        },
      },
      apns: {
        payload: { aps: { sound: "default", badge: 1 } },
      },
    });
  });

// ─────────────────────────────────────────────
//  AI: Smart Driver Matching (Callable)
// ─────────────────────────────────────────────
exports.findBestDriver = functions.https.onCall(async (data, context) => {
  if (!context.auth) throw new functions.https.HttpsError("unauthenticated", "يجب تسجيل الدخول");

  const { orderLocation, restaurantLocation, orderType, orderWeight } = data;

  // Get online available drivers
  const driversSnap = await db.collection("drivers")
    .where("isOnline", "==", true)
    .where("isAvailable", "==", true)
    .limit(20)
    .get();

  if (driversSnap.empty) return { error: "لا يوجد سائقون متاحون" };

  const drivers = driversSnap.docs.map(d => ({
    id: d.id,
    lat: d.data().currentLocation?.latitude,
    lng: d.data().currentLocation?.longitude,
    rating: d.data().rating,
    vehicleType: d.data().vehicleType,
    todayDeliveries: d.data().todayDeliveries || 0,
  })).filter(d => d.lat && d.lng);

  const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

  const prompt = `
أنت نظام ذكاء اصطناعي لمنصة FesDeliver في فاس، المغرب.
اختر أفضل سائق للطلب التالي:

الطلب:
- موقع المطعم: lat=${restaurantLocation.latitude}, lng=${restaurantLocation.longitude}
- موقع التوصيل: lat=${orderLocation.latitude}, lng=${orderLocation.longitude}
- نوع الطلب: ${orderType}
- الوزن التقريبي: ${orderWeight} كغ

السائقون المتاحون:
${JSON.stringify(drivers, null, 2)}

أجب بـ JSON فقط:
{
  "driverId": "...",
  "score": 0.95,
  "reason": "...",
  "estimatedPickupMinutes": 8,
  "estimatedDeliveryMinutes": 20
}
  `;

  const result = await model.generateContent(prompt);
  const text = result.response.text().replace(/```json|```/g, "").trim();

  return JSON.parse(text);
});

// ─────────────────────────────────────────────
//  NEW ORDER: Auto-assign driver using AI
// ─────────────────────────────────────────────
exports.onNewOrder = functions.firestore
  .document("orders/{orderId}")
  .onCreate(async (snap, context) => {
    const order = snap.data();
    const orderId = context.params.orderId;

    // Notify nearby merchants
    const merchantDoc = await db.collection("users")
      .where("restaurantId", "==", order.restaurantId)
      .where("role", "==", "merchant")
      .limit(1)
      .get();

    if (!merchantDoc.empty) {
      const fcmToken = merchantDoc.docs[0].data().fcmToken;
      if (fcmToken) {
        await admin.messaging().send({
          token: fcmToken,
          notification: { title: "🔔 طلب جديد!", body: `طلب بقيمة ${order.total} د.م.` },
          data: { orderId, type: "new_order" },
        });
      }
    }

    // Update order with AI match info
    try {
      const result = await exports.findBestDriver.run({
        orderLocation: order.deliveryLocation,
        restaurantLocation: { latitude: 34.0331, longitude: -5.0003 }, // mock
        orderType: "food",
        orderWeight: 1.5,
      });

      if (result.driverId) {
        await snap.ref.update({
          aiDriverMatch: result.reason,
          estimatedMinutes: result.estimatedDeliveryMinutes,
        });
      }
    } catch (e) {
      console.error("AI driver matching failed:", e);
    }
  });

// ─────────────────────────────────────────────
//  CLEANUP: Remove old notifications (weekly)
// ─────────────────────────────────────────────
exports.cleanupOldNotifications = functions.pubsub
  .schedule("every 168 hours")
  .onRun(async () => {
    const cutoff = admin.firestore.Timestamp.fromDate(
      new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) // 30 days
    );
    const snap = await db.collection("notifications")
      .where("createdAt", "<", cutoff)
      .limit(500)
      .get();
    const batch = db.batch();
    snap.docs.forEach(d => batch.delete(d.ref));
    await batch.commit();
    console.log(`Cleaned ${snap.size} old notifications`);
  });

// ─────────────────────────────────────────────
//  SECURITY: Validate promo code
// ─────────────────────────────────────────────
exports.validatePromoCode = functions.https.onCall(async (data, context) => {
  if (!context.auth) throw new functions.https.HttpsError("unauthenticated", "يجب تسجيل الدخول");

  const { code, orderAmount, userId } = data;

  const snap = await db.collection("promoCodes")
    .where("code", "==", code.toUpperCase())
    .where("isActive", "==", true)
    .limit(1)
    .get();

  if (snap.empty) return { valid: false, error: "كود الخصم غير صحيح" };

  const promo = snap.docs[0].data();

  // Check expiry
  if (promo.expiresAt && promo.expiresAt.toDate() < new Date()) {
    return { valid: false, error: "انتهت صلاحية الكود" };
  }

  // Check usage limit
  if (promo.usageLimit > 0 && promo.usageCount >= promo.usageLimit) {
    return { valid: false, error: "تم استنفاد هذا الكود" };
  }

  // Check minimum order
  if (orderAmount < promo.minOrder) {
    return { valid: false, error: `الحد الأدنى للطلب ${promo.minOrder} د.م.` };
  }

  // Calculate discount
  let discount = promo.type === "percent"
    ? (orderAmount * promo.value) / 100
    : promo.value;

  discount = Math.min(discount, promo.maxDiscount || Infinity);

  return { valid: true, discount, type: promo.type, value: promo.value };
});
