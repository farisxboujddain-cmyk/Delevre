# 🛵 FesDeliver — AI-Powered Delivery Platform

منصة توصيل ذكية مغربية مبنية بـ Flutter + Firebase + Gemini AI

---

## 🏗️ Project Structure

```
fesdeliver/
├── lib/
│   ├── main.dart                          # Entry point
│   ├── core/
│   │   ├── constants/app_constants.dart   # All app constants
│   │   ├── theme/app_theme.dart           # Green + Gold Moroccan theme
│   │   ├── models/models.dart             # Freezed data models
│   │   ├── router/app_router.dart         # GoRouter navigation
│   │   ├── shell/main_shell.dart          # Bottom nav shell
│   │   ├── providers/app_providers.dart   # Riverpod state
│   │   └── services/
│   │       ├── firebase_services.dart     # Auth, Firestore, Storage
│   │       ├── ai_service.dart            # Gemini AI (4 features)
│   │       ├── payment_service.dart       # Stripe integration
│   │       └── notification_service.dart  # FCM push notifications
│   └── features/
│       ├── auth/                          # Splash, Login, OTP
│       ├── home/                          # Restaurant list, search, AI suggestions
│       ├── restaurant/                    # Menu, categories, add to cart
│       ├── cart/                          # Cart, promo, payment, order creation
│       ├── orders/                        # Order history, reviews
│       ├── tracking/                      # Real-time map + status timeline
│       ├── wallet/                        # Balance, transactions, top-up, transfer
│       ├── chatbot/                       # Gemini AI chatbot
│       └── admin/                         # Dashboard, AI demand prediction
├── firebase_functions/
│   └── index.js                           # Cloud Functions (Stripe, AI, FCM)
├── firestore.rules                        # Security rules
└── pubspec.yaml                           # All dependencies
```

---

## ⚙️ Setup Guide

### 1. Firebase Setup

```bash
# Install FlutterFire CLI
dart pub global activate flutterfire_cli

# Configure Firebase (creates firebase_options.dart)
flutterfire configure --project=YOUR_PROJECT_ID
```

In Firebase Console:
- ✅ Enable **Authentication** → Phone + Google
- ✅ Enable **Firestore** → create database
- ✅ Enable **Storage**
- ✅ Enable **Cloud Messaging**
- ✅ Enable **Cloud Functions**

### 2. Google Maps

```xml
<!-- android/app/src/main/AndroidManifest.xml -->
<meta-data
  android:name="com.google.android.geo.API_KEY"
  android:value="YOUR_GOOGLE_MAPS_KEY"/>
```

```xml
<!-- ios/Runner/AppDelegate.swift -->
GMSServices.provideAPIKey("YOUR_GOOGLE_MAPS_KEY")
```

### 3. Stripe

```bash
# Add to .env or pass as --dart-define
STRIPE_PUBLISHABLE_KEY=pk_test_XXXX
STRIPE_SECRET_KEY=sk_test_XXXX  # Cloud Functions only
```

```bash
flutter run --dart-define=STRIPE_PUBLISHABLE_KEY=pk_test_XXX \
            --dart-define=GEMINI_API_KEY=AIzaSy...
```

### 4. Gemini AI

Get API key from [Google AI Studio](https://aistudio.google.com)

```bash
flutter run --dart-define=GEMINI_API_KEY=AIzaSy...
```

### 5. Deploy Cloud Functions

```bash
cd firebase_functions
npm install
firebase deploy --only functions
```

### 6. Deploy Firestore Rules

```bash
firebase deploy --only firestore:rules
```

### 7. Run the app

```bash
flutter pub get
flutter run
```

---

## 🤖 AI Features

| Feature | Description | Tech |
|---------|-------------|------|
| **Smart Driver Matching** | AI picks best driver based on location, rating, traffic | Gemini 1.5 Flash |
| **ETA Prediction** | Accurate delivery time based on real conditions | Gemini + distance calc |
| **AI Chatbot** | Multi-turn customer support in Moroccan Arabic | Gemini chat API |
| **Demand Prediction** | Forecasts busy hours + suggests dynamic delivery fees | Gemini + historical data |
| **Smart Recommendations** | Personalized food suggestions | Gemini |

---

## 👥 User Roles

| Role | Access |
|------|--------|
| **Customer** | Browse, order, track, wallet, chat |
| **Merchant** | Manage menu, accept/reject orders, earnings |
| **Driver** | See nearby orders, update status, location sharing |
| **Admin** | Full dashboard, AI insights, manage all users |

---

## 💳 Payment Flow

```
Customer → Select items → Cart
         → Choose payment (Wallet / Card / Cash)
         → Stripe Payment Sheet (card/Apple Pay/Google Pay)
         → Cloud Function validates & charges
         → Order created in Firestore
         → FCM notification to merchant
         → AI assigns best driver
         → Real-time tracking
```

---

## 📊 Firestore Collections

```
users/{uid}
restaurants/{id}
  └── menuItems/{itemId}
orders/{id}
wallets/{uid}
transactions/{id}
drivers/{uid}
reviews/{id}
promoCodes/{id}
notifications/{id}
chats/{id}
```

---

## 🎨 Design System

| Token | Value |
|-------|-------|
| Primary Green | `#1B6B3A` |
| Gold | `#C9A84C` |
| Dark BG | `#0D1F14` |
| Card Dark | `#132A1C` |
| Font | Cairo (Arabic) |

---

## 🔒 Security

- All Firestore writes validated by security rules
- Wallet balance changes only via Cloud Functions
- Stripe secret key never in client code
- FCM tokens updated on each login
- Role-based access control throughout

---

## 📱 Screens

1. **Splash** — Animated logo + progress
2. **Login** — Phone OTP + Google Sign-in + Role selector
3. **Home** — Restaurant list, search, AI suggestions, active order banner
4. **Restaurant** — Menu with categories, add to cart
5. **Cart** — Items, promo code, payment selection, order summary
6. **Tracking** — Google Maps, real-time driver location, status timeline
7. **Orders** — History + reviews
8. **Wallet** — Balance, top-up, transfer, loyalty points
9. **AI Chatbot** — Gemini-powered support
10. **Admin Dashboard** — Stats, AI demand chart, orders, drivers

---

## 🚀 Next Steps

- [ ] Add Driver app screens (accept orders, live location updates)
- [ ] Add Merchant app screens (manage menu, orders dashboard)
- [ ] Integrate Google Maps Directions API for real routes
- [ ] Add Firebase Analytics events
- [ ] Set up CI/CD with Fastlane
- [ ] Add offline support with Hive
- [ ] Integrate Vertex AI for production-grade AI
- [ ] Add multi-language (Arabic / French / English)
- [ ] Build web admin panel with Flutter Web

---

Built with ❤️ for Morocco 🇲🇦 | Powered by Flutter + Firebase + Gemini AI
